# Rise of Form / Werden der Form: Typst book toolchain (adopted 2026-08-25)

Replaces the WeasyPrint pipeline (build_pdf8.py / build_pdf9.py) for the book. The canonical
chapter sources are now the `.typ` files under `chapters/`; the Markdown drafts in the snapshot
are history and are no longer edited.

## Layout
    template.typ            shared styles: Barlow, A4, accent draft line, chapter openers, code, tables
    book-en.typ             assembled English draft (parts, planned-chapter notes, outline)
    book-de.typ             assembled German draft
    chapters/en/NN-slug.typ one file per written chapter, NN = position in the plan v0.56 TOC
    chapters/de/NN-slug.typ German chapters (same numbering)
    fonts/                  Barlow (OFL), the family the old PDFs used; no system fonts needed
    build.py                builds both books and one PDF per chapter, then runs the dash check
    convert.py              the one-off Markdown migration (kept for the record, not needed again)

## Chapter file conventions
    #import "../../template.typ": *
    = Chapter Title                         (level 1: chapter)
    #draftline[Chapter draft v0.6, ...]     (the accent line under the title)
    #frontnote[...]                         (chapter 1 only: the italic contract note)
    == Section Title                        (level 2: section)
    #strong[Notes and sources.] ...         (notes paragraphs, as before)
    ```                                     (reduction traces, verbatim monospace)

A new chapter: create chapters/en/NN-slug.typ with the header above, add one `#include` line to
book-en.typ under its part, run build.py. A new version: bump the number in the draft line; the
per-chapter PDF name picks it up automatically.

## Setup (fresh sandbox, network on)
    pip install typst --break-system-packages     # Typst 0.15 compiler, bundled, ~30 s
    python3 build.py                              # outputs to /mnt/user-data/outputs
pandoc is only needed for convert.py. pdftotext (poppler) is preinstalled and used by the check.

## Rules carried over
- No em or en dashes. Typst turns `--` and `---` into dashes at parse time, so never write two
  hyphens in prose (the table separator in Markdown was the only case; it is gone now).
  build.py extracts the text of every PDF and fails if a dash is found; template.typ additionally
  flattens any dash that reaches layout.
- Language per book: `lang: "en"` / `lang: "de"` in the book files drives hyphenation and quote
  style. Straight quotes in the source are set as ‘ ’ in English and „ “ in German.
- Outputs go to /mnt/user-data/outputs.

## Not yet done
- Agenda and concordance still use the WeasyPrint scripts; moving them onto template.typ is the
  natural next step so WeasyPrint can be dropped from the setup list.
- Idris syntax highlighting: the chapters' code fences are combinator traces without a language
  tag, so nothing was needed. When a chapter quotes Idris2, add a sublime-syntax file and
  `#set raw(syntaxes: "idris.sublime-syntax")` in template.typ.
- German chapters 2, 3, 4 and the Vessel resync (v0.3 -> v0.5) are content work, unchanged.

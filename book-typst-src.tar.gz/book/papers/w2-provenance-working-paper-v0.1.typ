#import "../template.typ": *
#show: book-setup.with(title: "Provenance: The Chain of Custody of Every Record", lang: "en", running: "Provenance: The Chain of Custody of Every Record")

= Provenance: The Chain of Custody of Every Record
#draftline[Working paper v0.1, Project secret3, Row A, line W2, August 11, 2026]

== 1. The claim
Nothing in a record is about anything the run never met. Stated with the module's precision: markers cannot be minted. A variable is the calculus's perfect tracer, inert under both moves, never manufactured by a firing, only carried, copied, or dropped; and the theorem says that a tracer present in any result of any walk was present in the walk's input. Aboutness at the form level is exhausted by ancestry: every record has a genealogy, and the genealogy runs backward through actual meetings, without exception. This is the second compiled edge of Part Three's silhouette, and the measurement chapter's formal floor.

== 2. The theorems as checked
Module Provenance, the fourteenth of the package, checked in seconds on the cached foundation. The occurrence meter occ, delivered long ago in the linearity campaign, counts a marker's appearances. Four results:

```
stepNoMint  : Step  t u -> occ x t = 0 -> occ x u = 0
stepsNoMint : Steps t u -> occ x t = 0 -> occ x u = 0
provenance  : Steps t u -> Not (occ x u = 0) -> Not (occ x t = 0)
custody     : Steps (App q a) r -> Not (occ x r = 0) ->
              Either (Not (occ x q = 0)) (Not (occ x a = 0))
```

The one-step lemma is a four-case ledger audit. The Kestrel firing drops the second argument, so surviving occurrences are a subset of the input's, the zero-split of a sum. The Starling firing is the interesting case: it duplicates the shared ground, so counts can grow, and the proof shows exactly why growth is not minting: the new occurrences are copies of old ones, and if the marker was absent from all three parts it is absent from both copies. Context steps recurse. The walk lemma folds the step lemma; provenance is its contrapositive, presence in the result forces presence in the input; and custody localizes the force at a meeting: a marker in the outcome of an application came in through one of the two parties, decided by case on the left party's count.

== 3. What the theorem does and does not say
It does say: no record produced by any run mentions a name the inputs did not carry; information has a chain of custody through firings; the Starling's copying inflates quantity and never provenance. It does not say that occurrence counts are preserved, they are not, the Kestrel burns and the Starling copies, and the linearity campaign priced both long ago; nor does it say anything about aboutness in the semantic sense the coin chapter reserved, the tracer result is about syntactic ancestry, and the paper marks the boundary before anyone else has to.

== 4. Readings, both at full strength
The offered reading, for the receiver chapter: a measurement record can only speak of what the apparatus actually met; knowledge at the form level is ancestry, and there is no action at an epistemic distance. Set beside the physics register: no signal without interaction, stated here as a theorem of the toy cosmos with the disanalogies owed, no locality metric, no light cone, a structural rhyme with receipts on our side only. The sober reading, printed whole: variable-freshness preservation is an elementary property of first-order rewriting, and its compilation adds certainty, not surprise; the words record, custody, and genealogy are chosen. The reader's chair, as always.

== 5. Service and status
W2 closes as delivered, packaged. Chapter twelve's provenance beat now stands on four receipts; the demon-judge unification gains the sentence it wanted, every notebook entry has an ancestor, and the finale's falsifiability section inherits the same floor. Package v0.4 ships fourteen modules; remaining on line W: W3, the registration-costs family, already mostly delivered by the ledgers, and W4, tier B. The fast lane's tally tonight: three theorems in three campaigns, W1, P1, W2, each checked in seconds.

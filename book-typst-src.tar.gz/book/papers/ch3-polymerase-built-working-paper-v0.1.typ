#import "../template.typ": *
#show: book-setup.with(title: "The Polymerase Built: Replication as Reflection, Enacted One-Handed", lang: "en", running: "The Polymerase Built: Replication as Reflection, Enacted One-Handed")

= The Polymerase Built: Replication as Reflection, Enacted One-Handed
#draftline[Working paper v0.1, Project secret3, Row A, line CH3, August 11, 2026]

== 1. The machine exists and its correctness is a theorem
CH3 delivers what CH2 constitutionalized: one closed term, the polymerase, and the compiled fact that for every strand it computes the complement, base for base, onto the antisense spine. Chiral.idr now stands at six hundred and ten lines, standalone, checking whole in seconds, and the run theorem reads:

```
polRun    : StepsC (POL applied to the active strand of bs)
                   (rchain (compStrandC bs))
polMirror : StepsC (the same run) (mirror (chain bs))
polTwin   : StepsC (the mirrored twin on the mirrored presentation)
                   (chain bs)
```

polMirror is the jewel the architecture promised: the machine, written entirely in the left hand and never containing a reflection, arrives at exactly the mirror of the passive strand. Replication is reflection, enacted asymmetrically. And polTwin closes the duplex: the mirror image of the polymerase, applied in the mirror geometry, walks the mirrored presentation back to the original sense strand. Two hands, one helix, both directions now theorems.

== 2. The architecture the constitution forced
Movement two proved the passive chain unreadable: a machine meeting a stored strand can only move itself or spend the template whole. So the polymerase consumes the strand's active form, actA, a self-folding presentation in which each letter is a left-hand selector and the whole is a program that walks itself. The storage form stays sealed; only what is actively presented is read, a distinction the calculus enforces rather than assumes. The machine itself is three pieces. The selectors, one per letter, four-continuation choosers built from the composer and the identity, whose pool lemma selPool is the recognition-emission joint: each letter, offered the four raw atoms, selects its complement, and the right-hand letters appear only as cargo, movement three's conservation holding by construction. The algebra takes a letter and the product so far and emits the complement onto the product, which, accumulating by application, lands on the opposite spine unasked: the antiparallel geometry is not imposed but arises from the only way an applicative world can append. And the primer is the right cap, so the empty strand yields it back.

== 3. The calculus writing its own proofs
The two long behavior lemmas, the cons node's seventeen moves and the algebra's forty, were not hand-derived: a twelve-line normalizer over the term trees computed the exact reduction sequences and emitted the step scripts, which the checker then certified unchanged. The method is worth its own sentence in the engineering log: where explicit chains grow past a dozen moves, let the calculus dictate them and let the checker judge; the author's role reduces to stating the destination.

== 4. Fences and readings
Geometry only, as before: no bonds, no energetics, and the active-passive distinction, for all its central-dogma flavor, is a fact about firing positions, not about transcription; the rhyme is marked as rhyme. The sober reading: this is a Church-encoded map over a list, verified by rewriting, and its charm is arrangement, not depth. The offered reading: a world with two hands and four letters contains, as a theorem, a one-handed machine whose every honest run writes the other hand's text, and whose own reflection completes the circle. Both printed; the chair is the reader's.

== 5. Status
CH3 closes as delivered, standalone, with the constitution's four movements covering the machine exactly as promised in advance: legible letters read through clean probes, the template untouched because never offered passively, the pool spent and never minted, and the antiparallel law instantiated twice, polMirror and polTwin. The chiral line stands complete through its chartered arc; what follows it, if anything, is new registration, not debt.

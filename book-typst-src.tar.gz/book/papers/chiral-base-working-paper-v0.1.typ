#import "../template.typ": *
#show: book-setup.with(title: "The Chiral Base: A Combinator Alphabet Built for Genetics", lang: "en", running: "The Chiral Base: A Combinator Alphabet Built for Genetics")

= The Chiral Base: A Combinator Alphabet Built for Genetics
#draftline[Working paper v0.1, Project secret3, line C8, August 11, 2026]

== Abstract
Asked to find a combinator base with very good properties for genetic modeling, this paper derives one rather than choosing one, and compiles its seed. The requirements come from the program's own receipts. Pairing must be found, not declared: with the two-letter base the swap involution is unique, and the BCWI note showed that four primitive letters admit three pairings, a choice where a discovery is wanted. Pairing must preserve inertness everywhere: the nucleic paper's zone theorem located the sole obstruction in the valence asymmetry of K against S, two against three, which ignites every S-headed letter at saturation two. The fix is therefore forced: seek a base in which complementation is a symmetry of the laws themselves, so that values map to values and redexes to redexes by construction. Binary trees admit exactly one canonical nontrivial symmetry, the mirror, and the mirror dictates the base: four atoms in two hands, a left Kestrel and left Starling firing on left spines, and their mirror twins, a right Kestrel and right Starling firing on right spines, with complementation the reflection that swaps hands and reverses every application. The seed calculus is compiled, standalone and first-try, as Chiral.idr: the step relation with its six mirror-paired rules; the involution mirrorInv; and the crown, mirrorStep, that every step maps to a step, hand for hand, side for side, six cases, each one constructor, so pairing is an automorphism of the dynamics and not a costume on the syntax. Three properties then arrive unbidden. Antiparallelism: the complement of a strand runs in the opposite direction, because the mirror reverses application, which is DNA's own geometry appearing as a structural fact rather than a stipulation. The bond-strength match: the weak pair A and T sits at valence two, as adenine and thymine share two hydrogen bonds, and the strong pair G and C at valence three, as guanine and cytosine share three; the calculus's two valences land on chemistry's two bond counts without being asked. And a mutation metric: within-hand changes and cross-hand changes give the alphabet a native two-level distance, transitions against transversions. Each hand alone is the complete two-move calculus, so nothing of expressiveness is lost, and the hands are reaction-orthogonal at the root, so a template strand of one hand is machinery-inert to the other, which is the sense and antisense architecture. The paper closes with the fork's honest status and its registered tasks.

== 1. Requirements from receipts
Seven requirements, each traceable to a theorem or a finding already on the shelf. R1, found pairing: the involution must be canonical, unique, discovered in the structure; two letters gave this for free, four primitive letters demonstrably do not. R2, universal inertness: complements of letters must be letters, complements of values values; the pairable-zone theorem showed the two-move base fails this outside saturation one, and named the valence asymmetry as the cause. R3, completeness: the machinery of readers and polymerases must remain constructible. R4, conservation: duplication by recruitment, erasure by release, so the mint law and its ledgers carry over. R5, strand-friendliness: letters inert as atoms, chains inert as spines, ideally without the songbook detour. R6, wished rather than required: some structural echo of the two bond strengths of real pairing. R7, wished: a native metric on the alphabet for mutation classes.

== 2. The search, and the forcing
Equal-arity two-letter bases fail R3 or R1 on inspection: three-ary erasers break bracket abstraction, and erasure-free pairs surrender completeness. Four primitive letters, the BCWI road, fail R1 by counting: three involutions, one choice. What remains is to stop varying the letters and vary the symmetry: demand that complementation be an automorphism of the reduction relation, so that R2 holds by construction, values to values, redexes to redexes, bijectively. An automorphism must act on the one binary operation the calculus has, application, and binary trees possess exactly one canonical nontrivial symmetry: reflection. So the involution is the mirror, and the mirror forces the base. If a left Kestrel fires on a left spine, its complement must be an atom that fires on the reflected shape, a right spine; likewise the Starlings. Four atoms, two hands, the rules of each hand the mirror images of the other. Nothing further is free to choose; the design is the fixed point of its own requirements.

== 3. The calculus, and the crown
The seed is ninety lines and compiles first try. The atoms are KL, SL, KR, SR; the left rules are the familiar two moves; the right rules are their reflections, arguments gathered on the right, the right Kestrel keeping its first-gathered and the right Starling sharing across the reflected spine. The mirror swaps hands and reverses every application; mirrorInv certifies the involution. And the crown is mirrorStep: every step of the calculus maps under the mirror to a step of the calculus, the left Kestrel's firing to the right Kestrel's, the left Starling's to the right Starling's, a step in a left context to a step in the mirrored right context, six cases, each discharged by exactly one constructor. Pairing, in this base, is not a function that happens to shuffle letters. It is a symmetry of the laws, and the proof is as short as the claim deserves.

== 4. Three gifts, unbidden
First, antiparallelism. The mirror reverses application, so the complement of a strand is the paired strand read in the opposite direction. In real DNA the two strands of the double helix are antiparallel, five prime to three prime against three prime to five prime, and every textbook must stipulate it; here it is a corollary of pairing being a reflection. Second, the bond-strength match. The four bases are the four atoms, so their valences are their identities: A and T, the Kestrel pair, sit at valence two; G and C, the Starling pair, at valence three. Adenine pairs thymine with two hydrogen bonds; guanine pairs cytosine with three. The calculus's only two numbers land on chemistry's only two bond counts, and nothing in the design aimed at it. Third, the mutation metric: a letter can change within its hand, Kestrel to Starling, or across hands, and the two-level structure is the transitions-against-transversions distinction of molecular genetics, native to the alphabet rather than imposed on it.

== 5. Status, tasks, boundary
The chiral base is a designed fork and says so: Chiral.idr stands beside the main module, self-contained, its whole-file check the one command, which the small module can afford. Each hand alone is the complete two-move calculus, so every campaign of the program, readers, ledgers, valence, transfers hand-wise by translation, cited not recompiled. The hands are reaction-orthogonal at the root, left rules blind to right atoms and conversely, which gives the sense and antisense architecture for free: a template strand of the right hand is machinery-inert to left-hand enzymes except through recognition, exactly the role templates play. Registered tasks: CH1, the strand-inertness lemma, that a right-nested chain of atoms admits no step at all, provable and queued; CH2, the chiral polymerase, the natural retargeting of the N2 campaign onto this base, awaiting the author's word; CH3, cross-hand recognition rules, how a left machine reads right letters, the design point where pairing-at-a-distance enters. The standing boundary is unchanged and stated once more: no energies, so bond strength here is valence structure, not thermodynamics; the two and the three are the right numbers for the wrong, or at least not yet the right, reason, and line C6's open half is where that reason would live.

== Appendix A: Methods
Chiral.idr, standalone module, %default total, no postulates, no holes; idris2 \-\-check Chiral.idr completed clean on first attempt and is the entire verification of the seed. The main module Proofs.idr is untouched by this paper.

== Appendix B: The seed module, verbatim
```idris
||| The chiral base: a four-atom combinator calculus designed for
||| genetic modeling. Two hands, each a complete K and S pair; the
||| right hand gathers its arguments on the right; complementation
||| is the mirror, the unique reflection symmetry of binary trees.
module Chiral

%default total

||| four atoms, two hands
data TermC : Type where
  KL : TermC
  SL : TermC
  KR : TermC
  SR : TermC
  AppC : TermC -> TermC -> TermC

||| the step relation: left-hand atoms fire on left spines,
||| right-hand atoms on right spines, mirror rules of one another
data StepC : TermC -> TermC -> Type where
  RdKL : StepC (AppC (AppC KL a) b) a
  RdSL : StepC (AppC (AppC (AppC SL a) b) c)
               (AppC (AppC a c) (AppC b c))
  RdKR : StepC (AppC b (AppC a KR)) a
  RdSR : StepC (AppC c (AppC b (AppC a SR)))
               (AppC (AppC c b) (AppC c a))
  CtL : StepC f g -> StepC (AppC f a) (AppC g a)
  CtR : StepC a b -> StepC (AppC f a) (AppC f b)

||| the mirror: swap hands and reflect every application
mirror : TermC -> TermC
mirror KL = KR
mirror SL = SR
mirror KR = KL
mirror SR = SL
mirror (AppC f a) = AppC (mirror a) (mirror f)

||| the mirror is an involution
mirrorInv : (t : TermC) -> mirror (mirror t) = t
mirrorInv KL = Refl
mirrorInv SL = Refl
mirrorInv KR = Refl
mirrorInv SR = Refl
mirrorInv (AppC f a) =
  rewrite mirrorInv f in
  rewrite mirrorInv a in Refl

||| the crown: the mirror is a symmetry of the laws themselves;
||| every step maps to a step, hand for hand, side for side
mirrorStep : {t, u : TermC} -> StepC t u ->
  StepC (mirror t) (mirror u)
mirrorStep RdKL = RdKR
mirrorStep RdSL = RdSR
mirrorStep RdKR = RdKL
mirrorStep RdSR = RdSL
mirrorStep (CtL s) = CtR (mirrorStep s)
mirrorStep (CtR s) = CtL (mirrorStep s)

||| the four bases are the four atoms: A and T the weak pair at
||| valence two, G and C the strong pair at valence three
data BaseC : Type where
  BA : BaseC
  BT : BaseC
  BG : BaseC
  BC : BaseC

baseAtom : BaseC -> TermC
baseAtom BA = KL
baseAtom BT = KR
baseAtom BG = SL
baseAtom BC = SR

||| Watson and Crick pairing is the hand swap
pairB : BaseC -> BaseC
pairB BA = BT
pairB BT = BA
pairB BG = BC
pairB BC = BG

||| pairing is the mirror, letter by letter
basePairing : (b : BaseC) ->
  mirror (baseAtom b) = baseAtom (pairB b)
basePairing BA = Refl
basePairing BT = Refl
basePairing BG = Refl
basePairing BC = Refl

||| every atom is inert: no atom takes a step
atomInert : (b : BaseC) -> StepC (baseAtom b) u -> Void
atomInert BA s impossible
atomInert BT s impossible
atomInert BG s impossible
atomInert BC s impossible

||| pairing is an involution at the alphabet
pairInv : (b : BaseC) -> pairB (pairB b) = b
pairInv BA = Refl
pairInv BT = Refl
pairInv BG = Refl
pairInv BC = Refl

||| strands and replication fidelity, base for base
StrandC : Type
StrandC = List BaseC

compStrandC : StrandC -> StrandC
compStrandC [] = []
compStrandC (b :: bs) = pairB b :: compStrandC bs

replicationExactC : (s : StrandC) ->
  compStrandC (compStrandC s) = s
replicationExactC [] = Refl
replicationExactC (b :: bs) =
  rewrite pairInv b in
  rewrite replicationExactC bs in Refl
```

== References
+ Project secret3, Nucleic Combinators I (v0.1) and The Other Alphabet (research note v0.1), whose zone theorem and pairing-uniqueness finding are the requirements this design satisfies.
+ Curry and Feys, Combinatory Logic (1958), for per-hand completeness.
+ Watson and Crick (1953), for the antiparallel double helix and the two bond counts the design lands on.

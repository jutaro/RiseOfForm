#import "../template.typ": *
#show: book-setup.with(title: "Purity Priced: The Registration-Costs-Bonds Family", lang: "en", running: "Purity Priced: The Registration-Costs-Bonds Family")

= Purity Priced: The Registration-Costs-Bonds Family
#draftline[Working paper v0.1, Project secret3, Row A, line W3, August 11, 2026]

== 1. The claim
To register is to build, and building stands on bonds. The purity fact itself, that a rewriting cosmos has no side channels and a meeting's output is everything the meeting produces, is a design truth of the framework, stated as such since the concept note. What this campaign compiles is that fact's countable shadow, a family of six results on the bond meter: the bondless are silent; what has no structure goes nowhere and writes nothing; any change at all presupposes at least one standing bond; the Kestrel's bill is exact, two bonds erased and a ledger discarded whole; and the Starling's entire growth is one copy of the shared ground, growth as copying and never as minting, the bond-level twin of W2's provenance.

== 2. The theorems as checked
Module Purity, the fifteenth of the package, checked in seconds. The meter: bonds counts application nodes, one per meeting-in-standing. The family:

```
zeroBondsAtomic     : bonds t = 0 -> AtomicT t
atomsAreSilent      : AtomicT t -> Step t u -> Void
bondlessWalksNowhere: bonds t = 0 -> Steps t u -> u = t
registrationCosts   : Steps t u -> Not (u = t) -> Not (bonds t = 0)
kFiringBill         : bonds (App (App CK a) b) = 2 + (bonds a + bonds b)
sFiringBill         : bonds (App (App a c) (App b c))
                    = bonds (App (App (App CS a) b) c) + bonds c
```

The first four form the silence ladder: no bonds, then atomic; atomic, then no move; no move, then the only walk is the empty walk; and therefore any real change certifies at least one bond standing ready before it. The two bills price the moves themselves, with sFiringBill carried by a spine ledger, a result ledger, and one pure ground shuffle, and its reading is the campaign's center: every bond the Starling adds is a copy of a bond the ground already carried.

== 3. The purity reading, assembled
Put the family beside the delivered edges and the identity the concept note promised becomes a chain of receipts. The crown, S K K, returns its partner untouched, skIdentity; a partner returned untouched is a walk ending where the record would have to differ, and registrationCosts says difference presupposes structure; the crown's own three bonds fire and vanish in the return, leaving the output that is, by design, everything; so perfect gentleness and perfect blankness are the same ledger read twice. In a pure world, to know is to touch, and the theorem family now prices the touch: at least one bond to act at all, two erased per forgetting, one ground copied per sharing.

== 4. Readings, both at full strength
The offered reading, for chapters eleven and twelve: observation without disturbance is observation without record, now with the cost table attached; the witness of the traditions, registering without touching, is priced out of form not rhetorically but arithmetically. The sober reading, printed whole: these are elementary structural counts on a first-order syntax, their compilation is bookkeeping, and the words record, silence, and gentleness are chosen; a deflationist reads the same table as inventory management. Both stand; the chair is the reader's.

== 5. Service and status
W3 closes as delivered, packaged. Line W now reads: W1 delivered, W2 delivered, W3 delivered, W4 tier B open by design. Part Three's silhouette stands on compiled edges alone except where a termination certificate is honestly named. Package v0.5, fifteen modules; the fast lane's tally tonight: four campaigns, four papers, every theorem in seconds.

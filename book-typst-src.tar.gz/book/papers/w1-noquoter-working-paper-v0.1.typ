#import "../template.typ": *
#show: book-setup.with(title: "The No-Quoter Theorem: The Witness's First Compiled Edge", lang: "en", running: "The No-Quoter Theorem: The Witness's First Compiled Edge")

= The No-Quoter Theorem: The Witness's First Compiled Edge
#draftline[Working paper v0.1, Project secret3, Row A, line W1, August 11, 2026]

== 1. The claim
No citizen of the forest can sing its colleagues' songs. Stated with care: let a song be any structural coding of terms, a function from terms to terms whose outputs are normal forms and which assigns different songs to at least the two witnesses named below. Then there is no term q that, by mere application, computes even those two songs correctly. The songbook that Part One's reader reads cannot have been written from inside the world it describes; whoever wrote it stood outside. This is the first of the four refusals whose combined silhouette is Part Three's subject, and it is now compiled.

== 2. The theorem as checked
The module NoQuoter, the eleventh of the package and the fast lane's first customer, compiles the following, with the checker silent in seconds. Normality is defined as the absence of any move, Nf t. The classical joint is carried as an explicit hypothesis named UNF, uniqueness of normal forms: if one term walks to two normal forms, they are equal. The witnesses are tOne, the identity applied to itself, and tTwo, the identity; the collision oneStepsTwo walks tOne to tTwo in two compiled moves, one Starling firing and one Kestrel firing. The lifting lemma stepsAppRight carries any walk under an application on the right. The theorem:

```
noQuoter :
  UNF ->
  (song : Term -> Term) ->
  ((t : Term) -> Nf (song t)) ->
  (song tOne = song tTwo -> Void) ->
  (q : Term) ->
  Steps (App q tOne) (song tOne) ->
  Steps (App q tTwo) (song tTwo) ->
  Void
```

The proof is five lines, and it is the classical argument with nothing hidden: from the quoting of tOne, the term App q tOne reaches song tOne; from the collision lifted under q and the quoting of tTwo, the same term also reaches song tTwo; both targets are normal by hypothesis; UNF forces the two songs equal; separation refuses. Read the hypotheses as the anatomy of the impossibility: to quote is to assign inert, distinct portraits, and a world whose only power is meeting cannot hold a portrait still while the sitter moves.

== 3. What is compiled and what is cited
Everything above is compiled except UNF itself, which is the corollary of confluence, Church and Rosser, 1936, and is carried as a named hypothesis rather than smuggled as a belief. This is the paper's honesty joint, and it is the same joint the machine chapter already declared: the book cites confluence classically, exactly once, exactly here. A future campaign, P1, may compile confluence on the typed garden and narrow the citation; the theorem's statement is already shaped to receive it.

== 4. The finding: our own songbook evades the theorem, and that is the point
Formalization returned a gift that reading never would have. The program's own coding, quote from the reader campaign, is not normal-valued: quote QS carries a Starling with a full hand and fires the moment three continuations arrive. Our songs are not portraits; they are actors, selectors that behave. So the C5 reader does not contradict the theorem it now lives beside; it explains, retroactively, why the reader had to be built the way it was. A structural songbook, inert and distinct, is uncomputable from inside; a behavioral songbook is computable and is exactly what the forest sings. The distinction the theorem draws, portrait against performance, is the distinction Part Three's gate has been standing on all along: within form, essence is invisible, and only behavior meets behavior.

== 5. Readings, both at full strength
The offered reading: measurement is conversation, never inspection; no citizen sees a colleague's anatomy, only its conduct; and the quantum no-cloning theorem is this theorem's cousin in the physical register, with the disanalogies listed before anyone else lists them, no amplitudes, no Born rule, a structural rhyme with receipts on our side only. The sober reading, printed whole: a rewriting calculus lacks a definable quoting function, a known corner of combinatory logic, formalized here in hypothesis-explicit form; the words witness and portrait are chosen, not derived. The reader's chair, as always.

== 6. Service and status
Chapter eleven's summit is armed: the two-line proof in forest dress, the identity fed to itself, two normal forms from one term, confluence refusing. Line W1 closes as delivered, packaged, the fast lane's protocol vindicated: seconds of checking on a cached foundation, the module in the shipped package v0.2. Lines W2 through W4 stand as registered; P1 would narrow this paper's one citation.

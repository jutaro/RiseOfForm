#import "../template.typ": *
#show: book-setup.with(title: "The Garden Ends, Twice: Strong Normalization Re-Proved in the Fast Lane", lang: "en", running: "The Garden Ends, Twice: Strong Normalization Re-Proved in the Fast Lane")

= The Garden Ends, Twice: Strong Normalization Re-Proved in the Fast Lane
#draftline[Working paper v0.1, Project secret3, Row A, line P1b, August 11, 2026]

== 1. What was hunted, what blocked, and what fell
P1b set out to compose Newman with the monolith's strongNorm and could not: every re-elaboration vehicle for part S failed, the minimal slice, the warm 2,229-line prefix, both swap regimes, all documented. So the campaign turned and took the mountain from the other side: strong normalization of the typed garden is now re-proved whole, in the fast lane, in a single module that checks in seconds, and the two garden theorems stand on it with #strong[zero citations of any kind]. Confluence compiled by P1, termination compiled by P1b, the arrival joint is closed.

```
gardenSN         : DedC a t -> SN t
gardenConfluence : DedC a t -> Steps t u -> Steps t v -> Joinable u v
gardenUNF        : DedC a t -> Steps t u -> Steps t v ->
                   Nf u -> Nf v -> u = v
```

== 2. The proof, restyled: satRed replaces the blowup block
The construction is the reducibility method, but the part that exploded in every earlier vehicle, the deep-clause head-expansion mutual, is replaced by one small machine. A datatype Sat marks the saturated terms, standing K and S redexes and their application columns, with the key fact compiled as satNoRootStep: applying a saturated term never creates a new root redex. On that spine sits satRed, the CR3 of this proof: a saturated term all of whose successors are reducible is reducible, by descent on the type at each application column, with a companion walker satCol descending on the argument's own ending. The two memberships then read like ledger entries: the Kestrel's, kClose, three exits by kView, the root exit paid by the hypothesis and the side exits by accessibility; the Starling's, sClose, four exits by sView, the root exit assembled from the three reducibilities meeting the shared ground, the side exits descending on the triple. Where the original proof carried twenty-one dependent clauses, this one carries four views and two closures, and the elaborator's load collapsed from unbounded to seconds.

== 3. The anomaly, minimally reproduced, and the workaround discipline
The campaign also caught the environment's ghost. A three-clause, Nat-valued pattern match on the typing derivations, imported or locally cloned, is rejected as non-covering by this build's checker, while structurally similar matches on Step and Sat succeed in the same module; the probe is preserved in the logs as M1b's minimal reproduction, and it retroactively explains the EyeOne failures. The workaround is now a named checker discipline: #strong[Church-encode what the checker will not split.] The derivations enter as their own recursors, DedC, with builders dK, dS, dMP and the sample idDed; consuming a derivation is application, never matching, and redDeriv is one line. Nothing is lost: the encoding is the family's universal property, and the identity's derivation, S K K at A implies A, builds and lands exactly as chapter seven's display promises.

== 4. The crown: the typed quoter needs no hypotheses at all
The composition closes W1's last opening. For a quoter whose run on the first witness is typed, the termination certificate is derived, not assumed: noQuoterGarden takes the coding, its normality, its separation, and one derivation, and delivers the impossibility with nothing classical anywhere in the chain, localConf to newman to gardenSN to the collision. The structural songbook is now uncomputable by theorem alone, end to end, on the garden.

== 5. Readings and service
The offered reading: the garden agrees with itself and ends, and both facts are now checked, not trusted; the machine chapter's arrival sentence, the coin's derivation runs, and the physics chapter's covariance jewel all stand on receipts on our side of every rhyme. The sober reading: Tait's method is fifty years old, and re-proving it is engineering; the anomaly is a build's bug, not a discovery about logic. Both printed; the chair is the reader's. Status: P1b closed as delivered, packaged, module seventeen, package v0.7; part S's content is no longer hostage to any vehicle, since the garden's ending is re-proved where every future campaign can reach it in seconds.

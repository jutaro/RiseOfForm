#import "../template.typ": *
#show: book-setup.with(title: "Confluence Without Citation: Local Confluence and Newman, Compiled", lang: "en", running: "Confluence Without Citation: Local Confluence and Newman, Compiled")

= Confluence Without Citation: Local Confluence and Newman, Compiled
#draftline[Working paper v0.1, Project secret3, Row A, line P1, August 11, 2026]

== 1. What was hunted and what was caught
Line P1 set out to upgrade the book's one confluence citation. It caught more than registered: after this campaign, #strong[confluence is no longer cited anywhere in the program; only termination is]. Two theorems, both fully compiled in the fast lane, do the work. First, local confluence of the untyped calculus: every one-step peak rejoins. Second, Newman's lemma: at any strongly normalizing point, local confluence yields confluence, hence uniqueness of arrival. The classical Church-Rosser theorem, cited since the machine chapter at exactly one joint, is thereby reduced: what remains citable is not the global geometry of walks but a single termination certificate for the walk in question, and on the typed garden even that certificate is a compiled theorem of the monolith, strongNorm.

== 2. The two theorems as checked
#strong[Local confluence] (module LocalConf, thirteen-module package v0.3, checked in seconds). The proof is a disciplined peak analysis through head-inversion helpers: stepKa and stepSa show that a step out of an atom applied once happens in the argument; stepSab splits a step out of S applied twice; kPeak joins a root Kestrel firing against any rival step, in at most one move each side; sPeak joins a root Starling firing against any rival, where a step in the shared ground costs two moves on the fired side, the priced shadow of duplication; and localConf assembles the peaks, with the two context rows commuting and the nested cases recursing structurally.

```
localConf : Step t u -> Step t v -> Joinable u v
```

#strong[Newman] (module Newman). Strong normalization enters as a local accessibility predicate, SN, one constructor: every successor is accessible. The lemma is the classical diagram chase, six lines, recursion descending along accessibility twice:

```
newman : SN t -> Steps t u -> Steps t v -> Joinable u v
unfAt  : SN t -> Steps t u -> Steps t v -> Nf u -> Nf v -> u = v
```

#strong[The upgraded no-quoter.] W1's theorem carried uniqueness of normal forms as a global hypothesis. It now carries one termination certificate instead: noQuoterSN replaces UNF with SN of the quoter's own run on the first witness. The impossibility of the structural songbook now rests on nothing classical at all beyond the ending of one walk, which is what any purported quoter would exhibit by succeeding.

== 3. The blocked corollary and the finding, P1b
The intended garden corollaries, gardenConfluence and gardenUNF, compose newman with the monolith's strongNorm and are six lines. They did not compile tonight, and the reason is now a triple-confirmed environment finding rather than a conjecture: part S elaborates only inside the full monolith. The control slice SliceAB passed cleanly in the same session; a minimal 340-line slice containing part S was killed; and the warm-prefix file, the monolith's own first 2,229 lines verbatim plus the six-line corollaries, was killed as well, though the historical full check to line 3,644 stands on record. The composition is therefore registered as P1b, blocked on the S-context vehicle, with the M1b reproduction enriched by tonight's three data points. Nothing in the two compiled theorems depends on it; the corollaries are one application away whenever the vehicle exists.

== 4. What the joint now says, chapter by chapter
The machine chapter's arrival sentence, all roads lead to the same normal form, was backed by a citation; it is now backed by compiled localConf plus compiled newman plus the garden's own compiled termination, with the composition pending P1b, and honesty keeps one clause of citation alive exactly there. The coin chapter's derivation-running inherits the same upgrade. The Unfinished Physics chapter's jewel, Church-Rosser as our general covariance, gains a receipt on our side of the rhyme: many foliations, one arrival is now, at every terminating point, our theorem. And W1's paper amends its section three: the citation it declared has been narrowed to a termination certificate, noQuoterSN, in the same package.

== 5. Readings, both at full strength
The offered reading: the world needs no referee to agree with itself; wherever a story ends, all tellings end alike, and the law that guarantees it is now checked, not trusted. The sober reading: Newman's lemma is a century old, local confluence of combinatory reduction is textbook, and compiling them adds certainty, not novelty; the shrinking of a citation is bookkeeping. Both true; the reader's chair. The program's own criterion is the second reading's last word turned around: bookkeeping is exactly what this program is for.

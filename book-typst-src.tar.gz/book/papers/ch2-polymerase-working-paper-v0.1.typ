#import "../template.typ": *
#show: book-setup.with(title: "The Chiral Polymerase, Movements One to Four", lang: "en", running: "The Chiral Polymerase, Movements One to Four")

= The Chiral Polymerase, Movements One to Four
#draftline[Working paper v0.1, Project secret3, Row A, line CH2, August 11, 2026]

== 1. What the movements are
CH2 delivers the polymerase's ground rules rather than its gears: four compiled movements stating what any replicating machine in the chiral calculus must respect. The concrete machine, read a strand and write its complement, is chartered as CH3 with the reader campaign's playbook; tonight's movements are its constitution. Chiral.idr, standalone, three hundred and seventy lines, checks whole in seconds.

== 2. Movement one: legibility, with a checker-forced honesty
The four letters announce themselves behaviorally. The weak left letter fires at two on a left probe, the strong left at three; the weak and strong right letters fire at the mirrored probes, and the four firing lemmas are one step each. The cross-hand silences carry the campaign's found gem: as first stated, a right letter under a left probe was claimed silent for arbitrary probe arguments, and #strong[the checker refused, exhibiting the counterexample]: a reagent that happens to end in a right cap smuggles a right firing into the root. The lemmas now hold for clean probes, atomic reagents, and are total silences, no move at the root or anywhere below. Read biologically: recognition assays need clean reagents, and contamination is not a metaphor here but a constructor.

== 3. Movement two: the template is fixed
templateFixed gives the complete event view of a machine meeting a sense strand: every step is the machine's own move, or the machine's own shape consumes the template whole, discarded by a standing Kestrel or duplicated by a standing Starling. The template itself never stirs, strandNoStep from the previous paper, and is never entered: the right-hand root rules are shown impossible against a strand's spine by shape alone. Semiconservative reading, with the fence up: the template survives every operation that does not deliberately spend it, and even spending touches it only as an unopened whole.

== 4. Movement three: the pool
The atom meter occC counts one letter at a time, and stepNoMintC, stepsNoMintC compile the conservation: no firing, no run, ever mints a letter absent from its input. The Starling's duplication is copying, never creation, exactly as in the untyped program's provenance campaign. Consequence for any future polymerase: complementation spends stock. The machine must carry its letters, a nucleotide pool in the only sense the calculus can afford, because the template cannot transmute into its complement; the other hand's atoms must be imported, never conjured.

== 5. Movement four: the antiparallel law
mirrorSteps lifts the crown automorphism to whole runs, and the law follows in one line: any run of any machine on a sense strand, reflected, is a run of the twin machine on the reverse complement strand, step for step, hand for hand. Watson and Crick's antiparallel geometry, compiled once for all machines that will ever be written in this calculus, the polymerase of CH3 included in advance.

== 6. Fence and status
Geometry only: no hydrogen bonds, no energetics, no kinetics; the words template, pool, and polymerase are chosen, and every rhyme with molecular biology is a rhyme with receipts on this side alone. CH2 closes as delivered, standalone. CH3 is chartered: the concrete polymerase, built on movement one's clean probes as its instruction set, obeying movements two and three by theorem before it is even written, and covered by movement four the moment it exists.

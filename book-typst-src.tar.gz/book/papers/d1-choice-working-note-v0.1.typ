#import "../template.typ": *
#show: book-setup.with(title: "The Tagged Choice: The Dictionary's Or-Row, Compiled", lang: "en", running: "The Tagged Choice: The Dictionary's Or-Row, Compiled")

= The Tagged Choice: The Dictionary's Or-Row, Compiled
#draftline[Working note v0.1, Project secret3, Row A, line D1, August 11, 2026]

== 1. What was needed and what stands
The Machine Room's full dictionary claims that every logical word is a builder: and a pair, exists a witness-first pair, not a function into the empty type, and or a tagged choice. The first three had receipts; the or-row had none at the object level. It does now. Module Choice, the sixteenth of the package, compiles the tagged choice from the certified B chain and a four-move thrush, no abstraction engine, every step explicit, checked in seconds.

```
tx x         = S I (K x)                the thrush of x
leftTag  x   = B K (tx x)               hand the payload to the first handler
rightTag x   = K (tx x)                 hand the payload to the second

txBeta       : Steps (App (tx x) f) (App f x)                       four moves
leftTagBeta  : Steps (App (App (leftTag x) l) r) (App l x)
rightTagBeta : Steps (App (App (rightTag x) l) r) (App r x)
```

Elimination is application twice: the choice meets both handlers, and the tag itself selects which one meets the payload. That is the dictionary's sentence for or, now enacted: a disjunction is not a fact about two propositions but a package, a tag and its cargo, and to use it is to offer both continuations and let the package decide.

== 2. Two registers of the same row
The or of this program lives at two levels, and the note marks both. At the object level, the tags above. At the meta level, the row has been load-bearing all along: Either carries rootStatus, the gathering-or-firing dichotomy; stepSab, the two homes of a step out of the Starling's pair; and custody, the two doors a marker can have entered through. The dictionary's claim was never decoration; the program's own theorems have been speaking in tagged choices since the valence campaign, and the Machine Room can now point at both registers with receipts.

== 3. Status
D1 closes as delivered, packaged, package v0.6, sixteen modules. The fast lane's tally tonight: five campaigns, W1, P1, W2, W3, D1, every theorem in seconds. The Machine Room's dictionary is fully armed: pair, tagged choice, witness-first pair, and the empty-type refusals, each with a compiled exhibit.

#import "../template.typ": *
#show: book-setup.with(title: "Chiral II: Inert Strands, Antiparallelism as Equation, and the Polymerase Plan", lang: "en", running: "Chiral II: Inert Strands, Antiparallelism as Equation, and the Polymerase Plan")

= Chiral II: Inert Strands, Antiparallelism as Equation, and the Polymerase Plan
#draftline[Working paper v0.1, Project secret3, line C8, August 11, 2026]

== Abstract
The chiral campaign's second delivery, on the author's continue. Task CH1 is closed: strands of the chiral base, bases as bare atoms on a right-nested spine, are absolutely inert, no step firing at the root or at any depth (strandNoStep), and the antisense spine is inert by a proof that uses no case analysis at all, only the automorphism: a step in the mirror of a strand would mirror back to a step in the strand (antiStrandNoStep), the crown theorem mirrorStep earning its keep in four lines. Above both sits the delivery this paper is named for: antiparallelism as an equation. The theorem mirrorChain states that the mirror of a sense strand is exactly the complement strand laid on the opposite spine, mirror of chain bs equal to rchain of the complemented sequence: pairing reverses direction, base for base, terminator for terminator, which is the double helix's stipulated geometry appearing as six lines of induction. The paper then delivers the polymerase plan, campaign movement zero: the recognition analysis showing why the reaction orthogonality of the hands cuts both ways, a left machine cannot branch on right atoms because right atoms are inert to left rules, exactly the property that made them good template letters; the selector observation, that the left Kestrel and left Starling are behaviorally distinguishable at two arguments, one firing and one standing, but that stuck-against-fired is not a branch a term can take without a driver, which is the same lesson the reader campaign learned; and the resulting honest route, the machine reads templates of its own hand and emits the opposite hand's letters as inert cargo, with the C5 playbook, tags, eyes, dispatcher, knot, as the proven path, four movements mapped and the per-base bill forecast from the recruitment rule. Two checker disciplines join the program's list: dependent matching blocked by function-valued indices is unblocked by a shape view, and auto-bound implicits are erased and must be declared when a proof transports along them.

== 1. CH1: strands inert, and the view that proved it
The claim is total: nowhere in a strand does anything fire. Its proof met a checker fact worth recording. The step relation's source index is chain bs, a function of the list, and dependent matching will not split a function-valued index; the clauses were rejected wholesale. The unblocking is a view: a datatype ChainShape whose constructors rebuild exactly the strand shapes, CNil for the terminator and CCons for an atom on a spine, so that matching on the shape refines the term index constructor by constructor. Against the view, the impossibility clauses discharge cleanly: the left rules die on every base because atoms are not applications; the right rules die at spine depth two and three because the chain never places a right atom in tail position and its terminator is the left Kestrel; context steps on the left die on atoms, and context steps on the right recurse down the spine. Twenty one clauses, one recursion, and the lemma strandNoStep is total. The companion is prettier. The antisense spine's inertness needs no clauses at all: antiStrandNoStep transports a hypothetical step through the mirror, lands it on the sense strand by the involution, and hands it to strandNoStep. The automorphism theorem was advertised as pairing being a symmetry of the laws; here is the symmetry doing labor, halving a proof.

== 2. Antiparallelism as equation
Define the antisense spine rchain, left-nested and terminated by the right Kestrel, the mirror image of the sense layout. Then mirrorChain: the mirror of chain bs is rchain of the complemented sequence, proved by induction with one rewrite through basePairing per base. Read it in the double helix's own vocabulary: complementing a strand does not produce a parallel partner, it produces the paired sequence running the other way, five prime to three prime against three prime to five prime, and in this calculus that is not a stipulation about chemistry but a consequence of pairing being a reflection. The three gifts of the first chiral paper were antiparallelism, the bond count match, and the mutation metric; the first of the three is now an equation with a six line proof, and the strand infrastructure under it is certified inert on both spines.

== 3. Movement zero: the polymerase plan
The recognition analysis first, because it settles the architecture. The hands are reaction orthogonal: right atoms are inert to left rules. That was listed as a gift, the template strand safe from the machinery, and the gift has a price on its other face: a left machine cannot branch on a right atom, since branching is firing and right atoms do not fire on left spines. Nor can it branch on its own hand's letters naively: the left Kestrel at two arguments fires and the left Starling at two stands, a real behavioral difference, but stuck against fired is a fact about the world, not a branch a term can take; the reader campaign met precisely this wall and resolved it with quotation, tags, and eyes. The honest route follows: the polymerase reads templates written in its own hand, where the tag machinery of the C5 campaign applies verbatim, and emits the opposite hand's letters as inert cargo, the emission table being the pairing function atom for atom; the daughter accumulates on the antisense spine, so that mirrorChain is the correctness statement's shape, and the finished product is the certified antiparallel complement. Four movements, mapped onto the proven playbook: the chiral tags and the bench; the two eyes for the two left letters; the dispatcher walking the spine; the knot for arbitrary length, with the recruitment rule pricing each appended base and the mint law guaranteeing the daughter is paid for bond by bond. Cross-hand recognition proper, a left machine reading right letters directly, is thereby isolated as what it is, a new physical channel, hybridization, a rule extension where pairing at a distance would enter the calculus, and it stays registered as CH3, design point open, not smuggled into CH2.

== Appendix A: Methods
Chiral.idr at 187 lines, standalone, %default total, no postulates, no holes; idris2 \-\-check Chiral.idr is the entire verification and completed clean. Checker disciplines recorded for the program: function-valued indices block dependent matching and are unblocked by shape views; auto-bound implicits carry erased quantity and must be declared when the proof transports along them.

== Appendix B: The strand section, verbatim
```idris
||| a sense strand: bases as bare atoms on a right-nested spine,
||| terminated by the left Kestrel
chain : StrandC -> TermC
chain [] = KL
chain (b :: bs) = AppC (baseAtom b) (chain bs)

||| the antisense spine: left-nested, terminated by the right Kestrel
rchain : StrandC -> TermC
rchain [] = KR
rchain (b :: bs) = AppC (rchain bs) (baseAtom b)

||| the antiparallelism theorem: the mirror of a sense strand is
||| the complement strand laid on the opposite spine; pairing
||| reverses direction, as in the double helix
mirrorChain : (bs : StrandC) ->
  mirror (chain bs) = rchain (compStrandC bs)
mirrorChain [] = Refl
mirrorChain (b :: bs) =
  rewrite basePairing b in
  rewrite mirrorChain bs in Refl

||| the shape of a sense strand, as a view the checker can split
data ChainShape : TermC -> Type where
  CNil : ChainShape KL
  CCons : (b : BaseC) -> ChainShape t ->
          ChainShape (AppC (baseAtom b) t)

chainShape : (bs : StrandC) -> ChainShape (chain bs)
chainShape [] = CNil
chainShape (b :: bs) = CCons b (chainShape bs)

||| no step fires anywhere in a chain shape
noStepShape : ChainShape t -> StepC t u -> Void
noStepShape CNil s impossible
noStepShape (CCons BA sh) RdKL impossible
noStepShape (CCons BT sh) RdKL impossible
noStepShape (CCons BG sh) RdKL impossible
noStepShape (CCons BC sh) RdKL impossible
noStepShape (CCons BA sh) RdSL impossible
noStepShape (CCons BT sh) RdSL impossible
noStepShape (CCons BG sh) RdSL impossible
noStepShape (CCons BC sh) RdSL impossible
noStepShape (CCons BA sh) (CtL s) impossible
noStepShape (CCons BT sh) (CtL s) impossible
noStepShape (CCons BG sh) (CtL s) impossible
noStepShape (CCons BC sh) (CtL s) impossible
noStepShape (CCons b CNil) RdKR impossible
noStepShape (CCons b (CCons c CNil)) RdKR impossible
noStepShape (CCons b (CCons c (CCons d sh))) RdKR impossible
noStepShape (CCons b CNil) RdSR impossible
noStepShape (CCons b (CCons c CNil)) RdSR impossible
noStepShape (CCons b (CCons c (CCons d CNil))) RdSR impossible
noStepShape (CCons b (CCons c (CCons d (CCons e sh)))) RdSR impossible
noStepShape (CCons b sh) (CtR s) = noStepShape sh s

||| strands are absolutely inert: no step fires anywhere in a
||| sense strand, at the root or at any depth
strandNoStep : (bs : StrandC) -> StepC (chain bs) u -> Void
strandNoStep bs s = noStepShape (chainShape bs) s

||| transport a step along an equality of sources
transportStep : {t1, t2, v : TermC} -> t1 = t2 ->
  StepC t1 v -> StepC t2 v
transportStep Refl s = s

||| the antisense strand is inert too, by the automorphism alone:
||| a step in the mirror would mirror back to a step in the strand
antiStrandNoStep : {u : TermC} -> (bs : StrandC) ->
  StepC (mirror (chain bs)) u -> Void
antiStrandNoStep bs s =
  strandNoStep bs
    (transportStep (mirrorInv (chain bs)) (mirrorStep s))
```

== References
+ Project secret3, The Chiral Base (v0.1), whose crown theorem this paper puts to work.
+ Project secret3, The First Eye through The Knot, the playbook the polymerase movements follow.
+ Watson and Crick (1953), for the antiparallel geometry that mirrorChain compiles.

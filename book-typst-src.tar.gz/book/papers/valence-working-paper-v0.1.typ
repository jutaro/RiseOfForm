#import "../template.typ": *
#show: book-setup.with(title: "Valence: The First Atomic Property", lang: "en", running: "Valence: The First Atomic Property")

= Valence: The First Atomic Property
#draftline[Working paper v0.1, Project secret3, August 11, 2026]

== Abstract
The chemist's question on the program's agenda asks which laws of real chemistry are combinatorial theorems in disguise. This paper delivers the first property: valence. Define the valence of an atom as its bond turnover number, the count of spine bonds its reaction must break, so that valence of K is two and valence of S is three, which is arity read chemically. Three groups of theorems are compiled. First, the turnover characters: the K reaction breaks exactly its valence and forms nothing, a pure bond sink (kTurnover), while the S reaction breaks exactly its valence and forms exactly its valence, turnover neutral bond for bond (sTurnover). Second, the saturation theorem: the values of the calculus, the five normal head shapes, are exactly the undersaturated molecules, each with a head atom holding strictly fewer arguments than its valence (valuesUndersaturated); reactivity is saturation at valence, and the calculus's value against redex dichotomy is chemistry's unsaturated against saturated distinction, compiled. Third, the flow law: at every event, bonds broken plus bonds minted equal bonds formed plus bonds burned (turnoverBalance), the balance holds along every trace (traceTurnover), and along any computation whatsoever, since computation never mints, bonds broken equal bonds formed plus bonds burned (stepsBondFlow): reactions turn structure over and down, never up. The absorber's meal runs under the new meters: ten broken, six formed, four burned, per cycle. The paper closes with the registered bridge to physical simulation, a saturation-weighted collision rule for the vessel engine, and an honest boundary: real valence includes stable bonding preference, which these theorems do not yet touch.

== 1. The property chosen
Real atoms carry a small integer that governs their whole social life: carbon four, oxygen two, hydrogen one. The number says how many bonds the atom makes, which neighbors saturate it, and when it stops reacting. If any chemical law is a combinatorial theorem in disguise, this one should be first, because in our calculus every atom already carries a small integer that governs its whole social life: its arity. K fires with two arguments gathered; S with three. This paper takes the identification seriously, defines valence as the bond turnover number of the atom's reaction template, and asks what compiles.

== 2. Turnover: what each atom's reaction does to bonds
The K redex is two spine bonds deep; its firing dismantles both and assembles nothing, releasing the discarded argument whole. The S redex is three spine bonds deep; its firing dismantles all three and assembles exactly three, the two new applications and the new root. Both facts are compiled as the pair theorems kTurnover and sTurnover against the valence function. The chemical reading is sharp. K is the calculus's pure bond sink, an atom whose entire chemistry is exothermic disassembly: every firing retires two bonds from the world, which is the burn meter of the assembly ledger seen at atomic resolution. S is the calculus's only mover of structure, and it is turnover neutral: three broken, three formed, every firing, with the daughter copy's internal bonds paid by the recruit, as the ledger's sBonds already showed. An atom's chemistry, in this world, is its arity, and nothing else about it.

== 3. Saturation: values are the unsaturated species
Chemistry's other face of valence is saturation: an atom below its valence is reactive, an atom at its valence is done. The calculus has owned this distinction since the strong normalization campaign without naming it. The values, the five head shapes that take no root step, are K bare, S bare, K holding one, S holding one, S holding two, and the compiled theorem valuesUndersaturated exhibits, for each, its head atom and a strict inequality: the head holds fewer arguments than its valence. The dichotomy runs the other way too, and was compiled long before this paper in other clothes: the reader campaign's silence theorems are precisely the undersaturation cases, and its firing theorems are precisely saturation at valence. Root reactivity in the two move calculus is saturation, exactly, with no residue. What chemistry calls an unsaturated species, the lambda tradition calls a value; this paper's contribution is the compiled bridge between the two vocabularies.

== 4. The flow law
Put the meters together and a conservation identity appears that the assembly ledger implied but never stated: at every event, bonds broken plus bonds minted equal bonds formed plus bonds burned (turnoverBalance, four cases, each definitional). Folded along any trace it is traceTurnover, and specialized to computations, where the minting meter reads zero by stepsNeverMint, it becomes the paper's summary law, stepsBondFlow: along any reduction whatsoever, bonds broken equal bonds formed plus bonds burned. Reactions turn structure over, and the part not turned over is turned down, never up. The absorber's four move meal, already metered for mint and burn, now reports its full turnover: ten bonds broken, six formed, four burned, per cycle, compiled as tauMealBroken and tauMealFormed by direct evaluation of the certified chain.

== 5. Toward the physical simulation, honestly
What the vessel engine gains from this paper is an instrument panel with per atom resolution, and one registered experiment. The chemical fact that reactive species are the unsaturated ones suggests the natural next dial: collision and recruitment propensities weighted by saturation deficit, so that molecules whose heads sit below valence attract encounters, as unsaturated species do in real solution. The registered prediction is that saturation weighting shifts and sharpens the busy middle of the phase sweep; the engine work is tier two of the agenda's chemist's line and is not performed in this paper. The honest boundary is stated with equal weight: real valence is not only turnover, it is stable preference, the fact that carbon does not merely break and form four bonds but keeps four, an equilibrium property whose home is energy, and this calculus has no energies yet. The theorems above are the kinetic half of valence, delivered; the thermodynamic half is open, and the agenda says so.

== Appendix A: Methods
All theorems are in the shared proof module Proofs.idr, 3,578 lines after this paper's part Z, %default total, no postulates, no holes; idris2 \-\-check Proofs.idr is the entire verification, the seventh consecutive part to compile on first attempt.

== Appendix B: The valence section (module part Z)
```idris
------------------------------------------------------------------
-- Tier 2, part Z: valence (the first atomic property)
------------------------------------------------------------------

||| the two atomic kinds
data Atom : Type where
  AtomK : Atom
  AtomS : Atom

||| valence: the bond turnover number of an atom's reaction,
||| the count of spine bonds its firing must break
valence : Atom -> Nat
valence AtomK = 2
valence AtomS = 3

||| the head atom of a molecule, if any
headAtom : Term -> Maybe Atom
headAtom CK = Just AtomK
headAtom CS = Just AtomS
headAtom (Var x) = Nothing
headAtom (App f x) = headAtom f

||| spine saturation: how many arguments the head has gathered
spineCount : Term -> Nat
spineCount (App f x) = S (spineCount f)
spineCount CK = 0
spineCount CS = 0
spineCount (Var x) = 0

||| bonds broken and bonds formed by each event
brokenE : ChemEvent -> Nat
brokenE (ECond a b) = 0
brokenE (EClv a b) = 1
brokenE (EK a b) = 2
brokenE (ES a b c) = 3

formedE : ChemEvent -> Nat
formedE (ECond a b) = 1
formedE (EClv a b) = 0
formedE (EK a b) = 0
formedE (ES a b c) = 3

||| the K reaction breaks exactly its atom's valence and forms nothing:
||| K is a pure bond sink
kTurnover : (a, b : Term) ->
  (brokenE (EK a b) = valence AtomK, formedE (EK a b) = 0)
kTurnover a b = (Refl, Refl)

||| the S reaction breaks exactly its atom's valence and forms exactly
||| its atom's valence: S is turnover neutral, bond for bond
sTurnover : (a, b, c : Term) ->
  (brokenE (ES a b c) = valence AtomS,
   formedE (ES a b c) = valence AtomS)
sTurnover a b c = (Refl, Refl)

||| bond flow balances at every event: broken plus minted equals
||| formed plus burned
turnoverBalance : (e : ChemEvent) ->
  brokenE e + mintE e = formedE e + burnE e
turnoverBalance (ECond a b) = Refl
turnoverBalance (EClv a b) = Refl
turnoverBalance (EK a b) = Refl
turnoverBalance (ES a b c) = Refl

||| the values of the calculus are exactly the undersaturated
||| molecules: each has a head atom holding fewer arguments than
||| its valence
valuesUndersaturated : {t : Term} -> Val t ->
  (a : Atom ** (headAtom t = Just a, LT (spineCount t) (valence a)))
valuesUndersaturated VK  = (AtomK ** (Refl, LTESucc LTEZero))
valuesUndersaturated VS  = (AtomS ** (Refl, LTESucc LTEZero))
valuesUndersaturated VK1 = (AtomK ** (Refl, LTESucc (LTESucc LTEZero)))
valuesUndersaturated VS1 = (AtomS ** (Refl, LTESucc (LTESucc LTEZero)))
valuesUndersaturated VS2 =
  (AtomS ** (Refl, LTESucc (LTESucc (LTESucc LTEZero))))

||| run meters for turnover
brokenRun : List ChemEvent -> Nat
brokenRun [] = 0
brokenRun (e :: es) = brokenE e + brokenRun es

formedRun : List ChemEvent -> Nat
formedRun [] = 0
formedRun (e :: es) = formedE e + formedRun es

plusInterchange : (a, b, c, d : Nat) ->
  (a + b) + (c + d) = (a + c) + (b + d)
plusInterchange a b c d =
  trans (sym (plusAssociative a b (c + d))) $
  trans (cong (a +) (plusAssociative b c d)) $
  trans (cong (\w => a + (w + d)) (plusCommutative b c)) $
  trans (cong (a +) (sym (plusAssociative c b d))) $
  plusAssociative a c (b + d)

||| bond flow balances along every trace
traceTurnover : (tr : List ChemEvent) ->
  brokenRun tr + mints tr = formedRun tr + burns tr
traceTurnover [] = Refl
traceTurnover (e :: es) =
  trans (plusInterchange (brokenE e) (brokenRun es) (mintE e) (mints es)) $
  trans (cong ((brokenE e + mintE e) +) (traceTurnover es)) $
  trans (cong (+ (formedRun es + burns es)) (turnoverBalance e)) $
  sym (plusInterchange (formedE e) (formedRun es) (burnE e) (burns es))

||| along any computation, bonds broken equal bonds formed plus bonds
||| burned: reactions turn structure over and down, never up
stepsBondFlow : {t, u : Term} -> (ss : Steps t u) ->
  brokenRun (traceOf ss) = formedRun (traceOf ss) + burns (traceOf ss)
stepsBondFlow ss =
  let e0 = traceTurnover (traceOf ss) in
  rewrite sym (plusZeroRightNeutral (brokenRun (traceOf ss))) in
  rewrite sym (stepsNeverMint ss) in e0

||| the absorber's meal, metered for turnover: ten bonds broken,
||| six formed, four burned, per cycle
tauMealBroken : (x : Term) -> brokenRun (traceOf (tauAbsorbs x)) = 10
tauMealBroken x = Refl

tauMealFormed : (x : Term) -> formedRun (traceOf (tauAbsorbs x)) = 6
tauMealFormed x = Refl
```

== References
+ Project secret3, The Assembly Ledger (v0.1), whose mint and burn meters this paper refines to broken and formed.
+ Project secret3, Every Typed Song Ends (v0.1), whose value analysis part Z reads chemically.
+ Project secret3, The First Eye through The Knot, whose silence and firing theorems are the saturation dichotomy in reader's clothes.
+ Kruszewski and Mikolov, Combinatory Chemistry (2020, 2022), the neighboring conserving vessel, for the simulation direction.

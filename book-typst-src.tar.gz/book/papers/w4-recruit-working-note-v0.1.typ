#import "../template.typ": *
#show: book-setup.with(title: "The Stochastic Recruit: Many Histories, One Arrival", lang: "en", running: "The Stochastic Recruit: Many Histories, One Arrival")

= The Stochastic Recruit: Many Histories, One Arrival
#draftline[Working note v0.1, Project secret3, Row A, line W4, tier B, August 11, 2026]

== 1. What this is and what it is not
W4 is the one deliberately non-theorem on line W: an engine demonstration under the fifth criterion, which the note states before anything else. Nothing below proves anything; the proving is done, gardenUNF in the package. What the demonstration adds is sight: at many moments several moves are legal, a random scheduler actualizes one history from the garden of legal ones, and every terminating run, however different its path, arrives at the same normal form. The shape rhymes with state reduction, one outcome from many possibilities, and the rhyme is marked as a rhyme: legal moves are not amplitudes, a linear congruential generator is not the Born rule, and the agreement of arrivals is not an experimental discovery here but a compiled theorem being watched at work. The demonstration illustrates a receipt; it never replaces one.

== 2. The run, verbatim
W4.idr, one hundred and thirty lines, self-contained, deterministic seeds, enumerates every standing redex, fires one at random, and reports. The showcase term races a Kestrel discard against two self-applications; the knot is the S I I self-application that never ends. The output:

```
W4, the stochastic recruit: many histories, one arrival
term: ((K (((S K) K) ((S K) K))) (((S K) K) ((S K) K)))
  seed 1  steps 4  arrived: ((S K) K)
    history: R root root root
  seed 2  steps 3  arrived: ((S K) K)
    history: LR root root
  seed 3  steps 5  arrived: ((S K) K)
    history: R LR R root root
  seed 4  steps 5  arrived: ((S K) K)
    history: R LR LR R root
  seed 5  steps 5  arrived: ((S K) K)
    history: LR R LR R root
  seed 6  steps 5  arrived: ((S K) K)
    history: R R LR LR root
  seed 7  steps 5  arrived: ((S K) K)
    history: R R LR LR root
  seed 8  steps 3  arrived: ((S K) K)
    history: LR root root
verdict: 8 arrivals, all identical, as gardenUNF demands

the knot: (((S ((S K) K)) ((S K) K)) ((S ((S K) K)) ((S K) K)))
  seed 1  steps 200  no arrival (fuel spent)
    history: root R L L root RR R LR R L L root ...
  seed 2  steps 200  no arrival (fuel spent)
    history: root L L root RR RR L LRR LLR LRR R R ...
verdict: no arrival; histories wander and never meet a normal form
```

Eight seeds, six distinct histories, lengths three to five, one arrival, and the verdict line names the theorem it shadows. The knot's two runs spend their fuel wandering and never meet a normal form, the contrast the chapter twelve brief asked for: where there is an ending, all endings agree; where there is none, histories merely differ forever.

== 3. Service and status
W4 closes as delivered, engine tier, illustration only, with the fence in its first paragraph. #strong[Line W is complete]: W1 the no-quoter, W2 provenance, W3 the purity prices, W4 the recruit watched, three theorems and one illustration, exactly as the concept note drew them. Part Three's formal program is delivered in full; The Receiver's collapse-shape paragraph, if the chapter uses it at all, may point at this output and must lean only on the theorems beside it.

#import "../template.typ": *
#show: book-setup.with(title: "Rise of Form: Concordance of Papers, Module, and Chapters", lang: "en", running: "Rise of Form: Concordance of Papers, Module, and Chapters")

= Rise of Form: Concordance of Papers, Module, and Chapters
#draftline[Concordance v0.2, Project secret3, August 11, 2026]

Purpose: one table joining the two rows. For every chapter and section of the book, the formal claims it leans on, the module anchors by name, and the working paper that carries the verification. This document is the seed of the book's appendix, The Receipts. Status marks: \[d\] delivered, \[h\] delivered and held, \[p\] planned.

== 1. The papers, current inventory
+ Tree Numbers (working paper, at v0.5, appendix synchronized): tree numerals, grafting, leavesGraft, Theorem A in both directions.
+ Transparent Arithmetic (working paper, at v0.9, appendix synchronized): the rewriting arithmetic R1 to R4, Theorem B via the value ledger (boxReduces, the invariant family, afUnique), the cost formula boxLen, sumSteps with rLenSum.
+ The Linearity Ladder (working paper, at v0.1): the occurrence counter occ, R2 as the arithmetic's only erasing clause, R1 its only duplicating clause, kinship of R2 and the K move.
+ Combinator Soup, v0.3: the conserving reactor, tauAbsorbs, upsAbsorbs, normal-form facts, condMass, kBalanced, sBalanced, the null-model census, the recycling core, food closure.
+ Freezing and Flux, v0.1: the phase campaign, flux non-monotone with its maximum at the balanced melting fraction, diversity peaking with it, the two starvation regimes, glass and gas.
+ No Bird Sings Peirce, v0.1: the three-graded matrix, matSound, peirceNoProof, dneNoProof; the open half tTyped with tSteps.
+ A Verified Coin: Type Preservation, v0.1: derivAppInv, kInvTy, sInvTy, arrInj, derivPreserved, derivSteps; the quantity lesson.
+ The Entropy Budget of Multiplication, v0.1: stepDup, stepErase, dupMass, eraseMass, boxDup, boxErase, sumDup, sumErase, tSizeNum; the disagreement of prices and the Landauer reading.
+ A Quoted Alphabet, v0.1 (C5 stage one): Code, embed, quote, qSCase, qKCase, qAppCase, quoteClosed, quoteInj.
+ The Reader's Engine, v0.1 (C5 stage two): simStep, simSound, simNormal, simRun, simRunSteps; the view-lemma lesson.
+ Every Typed Song Ends, v0.1: strongNorm, strong normalization for the coin by reducibility with semantic neutrality; L1 closed.
+ The First Eye, v0.1 (movement one): the bench (sub1NoOcc, absSubSteps, abs2Beta), the tags, qMk, and readK with seven theorems.
+ The Second Eye and the Assembler, v0.1 (movement two): the bench through arity four, readS with nine theorems, the contractum assembled by qMk.
+ The Dispatcher, v0.1 (movement three): rootRead with nine theorems, exact agreement with the engine's root fragment.
+ The Knot, v0.1 (movement four): simT, the verified self-reader, simCorrectJ and simCorrectN over all codes; C5 complete.
+ Two Refusals, One Ledger, v0.1: occStepEq, occRunEq, noClone, noDelete, cloneBill, deleteBill; line Q opened.
+ The program note, v0.6, and the research agenda, v0.9: governance, not verification.

The module: Proofs.idr, 3,337 lines, %default total, no postulates, no holes; the one command: idris2 \-\-check Proofs.idr.

== 2. The concordance
#align(center)[#table(
  columns: 4,
  align: (col, row) => (auto,auto,auto,auto,).at(col),
  inset: 6pt,
  [Book location], [Claim carried], [Module anchors], [Paper],
  [1 Two Moves, The Law of Three \[d\]],
  [the two rules and application as the triad of the machinery],
  [the Step relation, RedK, RedS],
  [module only, by design],
  [1 Two Moves, The Price of Forgetting \[d\]],
  [K is the only mover that discards, and forgetting pays],
  [occ ledger; kinship clauses],
  [The Linearity Ladder; now sharpened by The Entropy Budget],
  [1 Two Moves, The Answer \[d\]],
  [composition and the crown],
  [bC, sb, skIdentity],
  [Tree Numbers; Transparent Arithmetic],
  [1 Two Moves, The Law of Seven \[d\]],
  [the sterile circle, the mirror, the ladder and the knot],
  [omegaCycle, mirror, yKnot, yUnfolds],
  [module; program note],
  [2 Everything from Two, The Workshop \[d\]],
  [true, false, the box and its openings; the eight-move run],
  [kTrue, skFalse, pairBeta, pairFst, pairSnd, skIdentity],
  [module part M; costs in Transparent Arithmetic (rLenSum, boxLen)],
  [2 Everything from Two, One Mountain \[d\]],
  [completeness of the two moves],
  [abs, absCorrect (the recipe as engine)],
  [The Vanishing Engine section of module part N, with chapter two],
  [2 Everything from Two, The Empty Symbol \[d\]],
  [the moves never look at the names; the checker understands nothing],
  [substSteps, absCorrect],
  [module; the closure claim rests on the mountain],
  [2 Everything from Two, The One-Second Test and The Inside \[d\]],
  [the border and the gate],
  [none, and saying so is the point],
  [none, by design],
  [3 The Unreachables, The Trees \[d\]],
  [numbers as trees, grafting multiplies leaves, Theorem A both ways, Theorem B by the ledger, the cost formula],
  [leavesGraft, boxReduces, the invariant family, afUnique, boxLen, tSizeNum],
  [Tree Numbers; Transparent Arithmetic; The Entropy Budget for tSizeNum],
  [3 The Unreachables, Alphabet and Open Country \[d\]],
  [Euclid, unique factorization, the distribution],
  [classical, cited],
  [none needed],
  [4 The Price List \[p\]],
  [costs exactly: steps, roads, heat],
  [boxLen, omegaCycle, boxDup, boxErase, sumDup, sumErase, tSizeNum],
  [Transparent Arithmetic; The Entropy Budget],
  [5 The Vessel \[p\]],
  [the devourer, the balanced world, glass, gas, the living middle],
  [tauAbsorbs, upsAbsorbs, condMass, kBalanced, sBalanced, normal-form facts],
  [Combinator Soup v0.3; Freezing and Flux v0.1],
  [6 The Machine That Runs Itself \[p\]],
  [the fixed point, readers, the quoted alphabet and the engine],
  [fondPoint, yKnot, yUnfolds, mirror; quote, quoteClosed, quoteInj; simSound, simNormal, simRunSteps; simT, simCorrectJ, simCorrectN],
  [A Quoted Alphabet; The Reader's Engine; The First Eye through The Knot],
  [7 The Question \[p\]],
  [the gate and the contract],
  [none, by design],
  [none],
  [8 Coin, The Same Table Twice and Run the Proof \[h\]],
  [axioms are the moves; proofs run and stay proofs],
  [Deriv, iTyped, bTyped, derivPreserved, derivSteps],
  [A Verified Coin: Type Preservation],
  [8 Coin, The Garden and the Rewinder \[h\]],
  [the classical border fenced; the open half; constructive infinity],
  [matSound, peirceNoProof, dneNoProof, tTyped, tSteps, yUnfolds, probeCert, strongNorm],
  [No Bird Sings Peirce; Every Typed Song Ends; Transparent Arithmetic for probeCert],
  [8 Coin, The Three Sayings \[h\]],
  [the reading of I, K, S],
  [skIdentity, iTyped; the K ledger; S as the share],
  [reading over the anchors above; contract register],
  [9 The Machine Room \[p\]],
  [how proofs are done; the blind witness],
  [the module itself as exhibit],
  [all papers as worked examples],
  [10 Thought Unbound \[p\]],
  [thought is not language and not machine],
  [substSteps, absCorrect recalled],
  [chapter two's spine; external science carries the rest],
  [11 The Witness \[p\]],
  [the two refusals; reception at scale],
  [noClone, noDelete, cloneBill, deleteBill as compiled cousins; the quantum theorems cited],
  [Two Refusals, One Ledger; classical physics, cited],
  [12 The Receiver \[p\]],
  [the receiving level in psychology],
  [none, by design],
  [none],
  [13 and 14, Finale \[p\]],
  [the road named; the reading stated],
  [recalls only],
  [the whole shelf],
  [Appendix, The Receipts \[p\]],
  [claim to theorem to paper],
  [this concordance, matured],
  [all],
)
]

== 3. Gaps and open items, honestly
Paper housekeeping is done: both first papers were synchronized on August 11, 2026, and their appendices now carry the module map instead of a verbatim copy, so they can no longer go stale. C5 is complete through the knot, and the normalization sequel is delivered; both debts of the first concordance are paid. The soup line's probe ledger (P1 remainder) is optional, wanted only if the Vessel chapters ask for it. Chapter one's Law of Three and Law of Seven rest on module and program note without a dedicated paper, which is judged correct for their content. No book claim currently points at a theorem that does not exist; the direction of debt runs the other way, compiled results (the engine, the budget) waiting for their chapters.

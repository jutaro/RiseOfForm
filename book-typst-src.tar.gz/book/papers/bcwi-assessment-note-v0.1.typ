#import "../template.typ": *
#show: book-setup.with(title: "The Other Alphabet: BCWI as Bases, a Compiled Assessment", lang: "en", running: "The Other Alphabet: BCWI as Bases, a Compiled Assessment")

= The Other Alphabet: BCWI as Bases, a Compiled Assessment
#draftline[Research note v0.1, Project secret3, line C8, August 11, 2026]

== Abstract
The author's question: could the nucleic alphabet be built on the classical combinators B, C, W, I instead of the K and S bases of Nucleic Combinators I? The question splits into two roads, and the interesting one compiles. Road (a), BCWI as new primitive atoms, is a fork into a different calculus and is assessed in prose: a richer valence table, one, two, three, three; the no-K variant as the no-erasure chemistry, a genuinely attractive exploratory line; and a structural demerit, that with four primitive letters the pairing involution is a choice among three, where with two letters it is unique. Road (b), BCWI as composite bases inside the two-move calculus, is assessed with theorems, module part AC, slice-verified. In Curry's standard presentations all four are values of the same saturation, S heads holding two arguments (bcwiVal), pairwise distinct (bcwiInj): a legitimate same-zone alphabet. And then the fatal compiled fact: the canonical duality ignites every letter (bcwiCompIgnites); each complement is a Kestrel at full valence, a live redex, so this alphabet admits no found pairing, and any Watson and Crick structure on it would have to be declared, surrendering exactly the jewel of Nucleic Combinators I, that pairing was discovered inside the calculus rather than modeled on top of it. The note's positive yield is a precise characterization the question forced: the pairable zone of the duality is exactly the values whose heads sit at saturation zero or one, an infinite family, and the entire BCWI alphabet lies outside it; the N1 alphabet is the minimal symmetric choice within it. Road (a) is registered as exploratory line C9 and not pursued here.

== 1. The two roads
Taking BCWI as bases can mean two things. It can mean changing the atoms of the world, a four-letter chemistry with B, C, W, I primitive: that is a new calculus, with its own module, and Section 3 weighs it. Or it can mean choosing the four classical combinators, in their standard presentations over K and S, as the letters of a strand alphabet inside the existing world, exactly as Nucleic Combinators I chose its four: that is a question about our calculus, and it has compiled answers.

== 2. The compiled assessment
Part AC fixes the four letters in Curry's standard presentations: B as S (K S) K, I as S K K, W as S S (K I), and C in its standard long form. Three theorem groups settle their candidacy. First, bcwiVal: all four are values, and moreover values of the same shape, an S head holding two arguments, one below the Starling's valence; as an alphabet they are same-zone and root-inert, which is what letters must be. Second, bcwiInj: pairwise distinct, so the alphabet does not smudge. So far, a legitimate alphabet, and in one respect a charming one, since its letters mean something, composition, exchange, duplication, identity. Third, the verdict: bcwiCompIgnites. Apply the canonical duality to any of the four, and the result is not a still letter but a Kestrel at full valence, a live redex, for every letter, uniformly. The rung these letters live on, S-headed at two, is precisely the asymmetric rung the first nucleic paper fenced, where the valence mismatch of the two moves, two against three, turns complementation into ignition. The duality that paired the N1 alphabet burns this one, all of it.

The question's positive yield is the precise boundary it forced into view. The duality preserves inertness exactly on the values whose heads sit at saturation zero or one: the two bare atoms, and any atom holding any single argument. That zone is infinite, and everything in it pairs; the S-headed-at-two shapes, where all of BCWI lives, are exactly the values outside it. So the N1 alphabet is not one arbitrary choice among many: it is the minimal symmetric choice inside the pairable zone, the two atoms and each atom doubled, and any enlarged nucleic alphabet must be drawn from the same zone, atoms holding single cargo, which is a design fact worth having in writing before N2 builds the polymerase.

== 3. Road (a), and line C9
As primitive atoms, BCWI would make a genuinely different chemistry, and the note records its attractions honestly before declining to pursue it. The valence table becomes one, two, three, three, a richer periodic column than our two and three. W is a valence-two recruiter, so copying is cheaper. And the variant without K at all, the BCI or BCIW world, is the no-erasure chemistry: nothing is ever dropped, every argument is used, the relevance logician's vessel, kin to the two refusals and to the reversible fragment of the opening chapters, with a gentler burn table. Against this: a fork abandons the 3,785-line module and its eleven-part campaign history; and with four primitive letters the pairing involution is a choice among three possibilities, so the found-not-modeled character of N1's pairing cannot be recovered by fiat. The exploratory line is registered as C9, the gentle chemistry, tier C, opened and not pursued, awaiting either the author's call or a stall on the main line.

== Appendix A: Methods
Module Proofs.idr at 3,785 lines after part AC; the part is verified against its exact dependency slice, SliceAC.idr, shipped beside the module, per the M1 regime recorded in Nucleic Combinators I; the slice check caught and corrected two wrong ignition witnesses before certification, which is the regime doing its job. The behavioral correctness of the four presentations as B, C, W, I, that they reduce as composition, exchange, duplication, and identity, is classical (Curry and Feys) and is cited, not compiled; part AC certifies shapes, distinctness, and ignition only, and says so.

== Appendix B: The assessment section (module part AC)
```idris
------------------------------------------------------------------
-- Tier 2, part AC: the other alphabet (BCWI assessed)
------------------------------------------------------------------

||| the four classical combinators as candidate letters
data BCWI : Type where
  LB : BCWI
  LC : BCWI
  LW : BCWI
  LI : BCWI

||| their standard presentations over the two moves (Curry)
bcwiTerm : BCWI -> Term
bcwiTerm LB = App (App CS (App CK CS)) CK
bcwiTerm LC =
  App (App CS (App (App CS (App CK (App (App CS (App CK CS)) CK))) CS))
      (App CK CK)
bcwiTerm LW = App (App CS CS) (App CK (App (App CS CK) CK))
bcwiTerm LI = App (App CS CK) CK

||| all four letters are values: a same-zone alphabet, each an
||| S head holding two arguments, one below the Starling's valence
bcwiVal : (b : BCWI) -> Val (bcwiTerm b)
bcwiVal LB = VS2
bcwiVal LC = VS2
bcwiVal LW = VS2
bcwiVal LI = VS2

||| the letters are pairwise distinct: the alphabet does not smudge
bcwiInj : (a, b : BCWI) -> bcwiTerm a = bcwiTerm b -> a = b
bcwiInj LB LB _ = Refl
bcwiInj LC LC _ = Refl
bcwiInj LW LW _ = Refl
bcwiInj LI LI _ = Refl
bcwiInj LB LC Refl impossible
bcwiInj LB LW Refl impossible
bcwiInj LB LI Refl impossible
bcwiInj LC LB Refl impossible
bcwiInj LC LW Refl impossible
bcwiInj LC LI Refl impossible
bcwiInj LW LB Refl impossible
bcwiInj LW LC Refl impossible
bcwiInj LW LI Refl impossible
bcwiInj LI LB Refl impossible
bcwiInj LI LC Refl impossible
bcwiInj LI LW Refl impossible

||| the fatal fact: the canonical duality ignites every letter;
||| each complement is a Kestrel at full valence, a live redex,
||| so this alphabet has no canonical Watson and Crick pairing
bcwiCompIgnites : (b : BCWI) ->
  (u : Term ** Step (compT (bcwiTerm b)) u)
bcwiCompIgnites LB = (compT (App CK CS) ** RedK)
bcwiCompIgnites LC =
  (compT (App (App CS (App CK (App (App CS (App CK CS)) CK))) CS)
   ** RedK)
bcwiCompIgnites LW = (CK ** RedK)
bcwiCompIgnites LI = (CS ** RedK)
```

== References
+ Curry and Feys, Combinatory Logic (1958), for the standard presentations and the BCKW base.
+ Project secret3, Nucleic Combinators I (v0.1), whose pairing jewel this note protects, and Coordination and Turnover (v0.1), whose saturation analysis the zone characterization extends.
+ Project secret3, The Linearity Ladder and Two Refusals, One Ledger, the kin of line C9's no-erasure vessel.

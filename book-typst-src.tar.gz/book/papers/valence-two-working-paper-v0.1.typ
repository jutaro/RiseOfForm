#import "../template.typ": *
#show: book-setup.with(title: "Coordination and Turnover: Valence II", lang: "en", running: "Coordination and Turnover: Valence II")

= Coordination and Turnover: Valence II
#draftline[Working paper v0.1, Project secret3, August 11, 2026]

== Abstract
This paper corrects a framing in its predecessor and delivers the theorem the correction demands. Valence I mapped the calculus's values to chemistry's unsaturated species and called the dichotomy the same; the stability semantics are in fact inverted, and the inversion is the finding. In shell chemistry the unsaturated species are the reactive ones and the saturated are inert; in this calculus the undersaturated heads are the values, inert at the root, and saturation at valence is precisely what triggers firing. The resolution is that these atoms are not shell-filling noble atoms but catalytic centers: sites that gather substrates until the coordination sphere is complete and then, exactly then, fire the elementary step and release products. Coordination, then turnover. The regime dichotomy is compiled for the first time as the progress theorem of the calculus: rootStatus, every closed molecule is either a value, the gathering regime, or possesses a root neighborhood step, the firing regime, with no third state, proved by structural induction over a closedness predicate. Around it, four small theorems pin the picture to the meters: firing happens exactly at valence (rootKSat, rootSSat), the atom that fires at a root redex is the head atom (firedK, firedS, tying the turnover ledger to headAtom), and condensation advances the head's saturation by exactly one (condGathers), so the gathering regime is a monotone climb toward valence, one rung per condensation. The consequence for the simulation line is that the registered saturation-weighted dial stops being a heuristic borrowed from solution chemistry and becomes the gathering regime's own law: condensation propensity by saturation deficit. The honest boundary is unchanged: the calculus still has no energies, and stable preference, why a real atom keeps its bonds, remains open.

== 1. The inversion, named
Valence I read the compiled fact that the five value shapes are exactly the undersaturated heads as chemistry's unsaturated against saturated distinction, and at the level of the census that is correct. At the level of behavior it is backwards, and a referee would say so: real unsaturated species are radicals and open shells, famously reactive, while saturated shells are the noble gases, famously inert. Here the undersaturated heads take no root step at all, and it is arrival at valence that fires. A mapping that silently flips reactivity is not yet a bridge between vocabularies. Either the identification fails, or our atoms are not the atoms of the shell picture. They are not, and saying which atoms they are is this paper's work.

== 2. Catalytic centers
Mechanism chemistry has a second picture of the small governing integer, and it fits this calculus without force. A catalytic center, an enzyme's active site, a metal in a complex, does its chemistry in two strokes: it gathers, binding substrates one by one until its coordination sphere is complete, and then it turns over, firing the elementary step, transforming the gathered material, releasing products, and standing ready again. Below full coordination such a site is not reactive in the transforming sense; it is receptive. At full coordination it acts. That is our chemistry to the letter. Below valence, an atom's head can change only by condensation, the background binding of one more argument; the value shapes are the receptive states. At valence, the redex exists and the atom's characteristic act runs: the Kestrel burning its two, the Starling turning over its three. The two moves are not noble atoms seeking closed shells. They are the calculus's two catalytic sites, and their valence is coordination number.

== 3. The two-regime law, compiled
The dichotomy deserves theorem status, and it now has it, under the name the typed tradition would use: progress. Define closedness as the predicate NoVar, and the theorem rootStatus states: every closed molecule is either a value or possesses a step in its root neighborhood, with no third state. The proof is a structural induction whose whole content lives in one lift, rsApp: given the status of a head, the status of the head with one more argument follows, value shapes climbing one rung until the two redex shapes tip over into firing, and a stepping head carrying its step outward through the context. Around the law, four theorems pin it to the paper's meters. Firing happens exactly at valence: the K redex carries its head at spine count two, the S redex at three, definitionally (rootKSat, rootSSat). The atom that fires is the head atom: the event of a root redex names the same atom that headAtom reads off the molecule (firedK, firedS), so the turnover ledger of Valence I and the anatomy of Valence II meter the same subject. And condensation gathers: one condensation advances the head's saturation by exactly one (condGathers), so the receptive regime is a monotone climb, rung by rung, toward the firing threshold. Gathering, then turnover, with the boundary at valence, all compiled.

== 4. What the simulation gains, and what stays open
The registered tier-two experiment asked for collision and recruitment propensities weighted by saturation deficit, and justified the weighting by analogy to reactive species in solution. The analogy can be retired: under the two-regime law, the weighting is the gathering regime's own statement. A head below valence has exactly one channel of change, condensation, and its distance from action is exactly its deficit; a propensity proportional to that deficit is not imported chemistry but the law's natural rate form, and the sweep's registered prediction, that the busy middle shifts and sharpens, now tests a law-shaped rule rather than a borrowed one. The reading of the vessel also sharpens: it is not a gas of noble atoms but a soup of catalytic centers, which sits considerably closer to the mechanism chemistry that prebiotic studies actually care about. The boundary stands where Valence I left it, stated once more so no reader mistakes the delivery: the calculus has no energies, so the thermodynamic half of valence, stable preference, why a real atom keeps what it has gathered, remains open, its home named and empty.

== Appendix A: Methods
All theorems are in the shared proof module Proofs.idr, 3,644 lines after this paper's part AA, %default total, no postulates, no holes; idris2 \-\-check Proofs.idr is the entire verification, the eighth consecutive part to compile on first attempt.

== Appendix B: The coordination section (module part AA)
```idris
------------------------------------------------------------------
-- Tier 2, part AA: coordination and turnover (valence II)
------------------------------------------------------------------

||| closed molecules: no free variables
data NoVar : Term -> Type where
  NVK : NoVar CK
  NVS : NoVar CS
  NVApp : {f, a : Term} -> NoVar f -> NoVar a -> NoVar (App f a)

||| lift a root status of the head through one application
rsApp : {f : Term} -> (a : Term) ->
  Either (Val f) (u : Term ** Step f u) ->
  Either (Val (App f a)) (u : Term ** Step (App f a) u)
rsApp a (Left VK) = Left VK1
rsApp a (Left VS) = Left VS1
rsApp a (Left (VK1 {x = p})) = Right (p ** RedK)
rsApp a (Left (VS1 {x = p})) = Left VS2
rsApp a (Left (VS2 {x = p} {y = q})) =
  Right (App (App p a) (App q a) ** RedS)
rsApp a (Right (f' ** s)) = Right (App f' a ** CtxL s)

||| progress, the two-regime law: every closed molecule is either
||| gathering (a value, head below valence) or firing (a root
||| neighborhood step exists); there is no third state
rootStatus : {t : Term} -> NoVar t ->
  Either (Val t) (u : Term ** Step t u)
rootStatus NVK = Left VK
rootStatus NVS = Left VS
rootStatus (NVApp nf na) = rsApp _ (rootStatus nf)

||| firing happens exactly at valence: the two root redexes carry
||| their head atom at saturation
rootKSat : (a, b : Term) ->
  spineCount (App (App CK a) b) = valence AtomK
rootKSat a b = Refl

rootSSat : (a, b, c : Term) ->
  spineCount (App (App (App CS a) b) c) = valence AtomS
rootSSat a b c = Refl

||| the atom of an event
eventAtom : ChemEvent -> Maybe Atom
eventAtom (EK a b) = Just AtomK
eventAtom (ES a b c) = Just AtomS
eventAtom (ECond a b) = Nothing
eventAtom (EClv a b) = Nothing

||| the atom that fires at a root redex is the head atom
firedK : (a, b : Term) ->
  eventAtom (stepEvent (RedK {a} {b})) = headAtom (App (App CK a) b)
firedK a b = Refl

firedS : (a, b, c : Term) ->
  eventAtom (stepEvent (RedS {a} {b} {c})) =
    headAtom (App (App (App CS a) b) c)
firedS a b c = Refl

||| condensation gathers: one condensation advances the head's
||| saturation by exactly one
condGathers : (f, x : Term) ->
  spineCount (App f x) = S (spineCount f)
condGathers f x = Refl
```

== References
+ Project secret3, Valence: The First Atomic Property (v0.1), whose census stands and whose behavioral framing this paper corrects.
+ Project secret3, Every Typed Song Ends (v0.1), for the value analysis; the progress theorem is its natural companion, compiled here.
+ Project secret3, The Assembly Ledger (v0.1), for the meters the fired-atom theorems now anchor.
+ Kruszewski and Mikolov, Combinatory Chemistry (2020, 2022), for the neighboring vessel the law-shaped dial will be compared against.

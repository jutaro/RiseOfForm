#!/usr/bin/env python3
"""Regenerate the table-of-contents documents from the assembled book PDFs.
Usage: python3 build.py <outdir> && python3 toc.py <outdir> && python3 build.py <outdir>
(the first build produces the books whose page numbers are read; the second builds the TOC PDFs).
Edit the planned-chapter names and the notes below when the plan changes.
"""
import re, pathlib, subprocess, sys, datetime
HERE = pathlib.Path(__file__).parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs")
TODAY = datetime.date.today()

def pages(pdf):
    return subprocess.run(["pdftotext", "-layout", str(pdf), "-"], capture_output=True).stdout.decode("utf-8", "replace").split("\f")
def norm(s): return re.sub(r"[\u2019'\u00ad]", "", s).strip()

def scan(lang, pdf):
    pg = [[norm(l) for l in p.splitlines()] for p in pages(pdf)]
    def find(s, start):
        s = norm(s)
        for i in range(start, len(pg)):
            if s in pg[i]: return i + 1
    chs = []
    for ch in sorted((HERE / "chapters" / lang).glob("*.typ")):
        t = ch.read_text(encoding="utf-8")
        title = re.search(r"^= (.*)", t, re.M).group(1); ver = re.search(r"v\d+\.\d+", t).group(0)
        secs = [l[3:] for l in t.splitlines() if l.startswith("== ")]
        cp = find(title, 2); last = cp - 1; sp = []
        for s in secs:
            p = find(s, last); sp.append((s, p)); last = (p or last + 1) - 1
        chs.append(dict(num=int(ch.stem[:2]), title=title, ver=ver, page=cp, sections=sp))
    return chs

PLANNED_EN = {9: "The Machine Room", 10: "Thought Unbound", 11: "The Witness", 12: "The Receiver", 13: "The Unfinished Physics", 14: "Spirit, Soul, and Form", 15: "The Two Courses"}
PLANNED_DE = {2: "Alles aus Zwei", 3: "Die Unerreichbaren", 4: "Die Preisliste", 9: "Der Maschinenraum", 10: "Denken entfesselt", 11: "Der Zeuge", 12: "Der Empf\u00e4nger", 13: "Die unvollendete Physik", 14: "Geist, Seele und Form", 15: "Die zwei Kurse"}
PARTS_EN = [("Part One, Form: The Country of Form", range(1, 7)), ("Part Two, Thought", range(7, 11)), ("Part Three, Consciousness", range(11, 14)), ("Finale", range(14, 17))]
PARTS_DE = [("Erster Teil, Form: Das Land der Form", range(1, 7)), ("Zweiter Teil, Denken", range(7, 11)), ("Dritter Teil, Bewusstsein", range(11, 14)), ("Finale", range(14, 17))]

def rows(chs, parts, planned, written, planned_label, backlog={}):
    by = {c["num"]: c for c in chs}; out = []
    for pt, rng in parts:
        out.append(f"  table.cell(colspan: 4, fill: luma(240))[#strong[{pt}]],")
        for n in rng:
            if n in by:
                c = by[n]
                out.append(f"  [{n}], [#strong[{c['title']}]], [{written} {c['ver']}], [{c['page']}],")
                for s, p in c["sections"]:
                    out.append(f"  [], [#h(1.2em){s}], [], [{p if p else ''}],")
            else:
                out.append(f"  [{n}], [{planned[n]}], [{backlog.get(n, planned_label)}], [],")
    return "\n".join(out)

HEAD = '''#import "../template.typ": *
#show: book-setup.with(title: "%s", lang: "%s", running: "%s")

= %s
#draftline[%s]

%s

#table(
  columns: (2em, 1fr, 9em, 3.5em),
  align: (right, left, left, right),
  stroke: none,
  inset: (x: 6pt, y: 4pt),
  table.header([], [%s], [%s], [%s]),
%s
)

%s
'''
VER = "v0.1"
en = scan("en", OUT / "rise-of-form-book-draft.pdf")
de = scan("de", OUT / "werden-der-form-buch-entwurf.pdf")
(HERE / "papers" / f"rise-of-form-table-of-contents-{VER}.typ").write_text(HEAD % (
    "Rise of Form: Table of Contents", "en", f"Rise of Form: Table of Contents {VER}", "Rise of Form: Table of Contents",
    f"Table of contents {VER}, Project secret3, Row B, {TODAY:%B %-d, %Y}",
    f"The sixteen chapters per plan v0.56, three parts and a finale, with every written chapter's sections and its page in the assembled draft (rise-of-form-book-draft.pdf, built {TODAY:%B %-d, %Y} from the Typst sources). Status: written, with the chapter draft version; planned, brief registered in the plan. Nine of sixteen are written. The writing queue is chapters 9 to 15, in door order.",
    "Chapter", "Status", "Page", rows(en, PARTS_EN, PLANNED_EN, "written", "planned"),
    "== Notes\n\nChapter numbers follow the plan; the file names in chapters/en carry the same numbers, so The Reading is 16-the-reading.typ although it currently follows chapter 8 in the assembled draft. Page numbers shift whenever a chapter is revised; this table is regenerated from the assembled draft by toc.py, not maintained by hand. Appendix, The Receipts, is planned and will be seeded from the concordance."), encoding="utf-8")
(HERE / "papers" / f"werden-der-form-inhaltsverzeichnis-{VER}.typ").write_text(HEAD % (
    "Werden der Form: Inhaltsverzeichnis", "de", f"Werden der Form: Inhaltsverzeichnis {VER}", "Werden der Form: Inhaltsverzeichnis",
    f"Inhaltsverzeichnis {VER}, Projekt secret3, Reihe B, {TODAY:%-d}. {['Januar','Februar','M\u00e4rz','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'][TODAY.month-1]} {TODAY.year}",
    f"Die sechzehn Kapitel nach Plan v0.56, mit den Abschnitten der \u00fcbersetzten Kapitel und ihrer Seite im zusammengestellten Entwurf (werden-der-form-buch-entwurf.pdf). Sechs Kapitel liegen auf Deutsch vor. R\u00fcckstand: Kapitel 2, 3 und 4, sowie der Abgleich des Gef\u00e4\u00dfes mit der englischen v0.5.",
    "Kapitel", "Status", "Seite",
    rows(de, PARTS_DE, PLANNED_DE, "\u00fcbersetzt", "geplant", {2: "\u00dcbersetzung ausstehend", 3: "\u00dcbersetzung ausstehend", 4: "\u00dcbersetzung ausstehend"}).replace("[\u00fcbersetzt v0.3]", "[\u00fcbersetzt v0.3, Abgleich mit v0.5 ausstehend]"),
    "== Anmerkungen\n\nDie Kapitelnummern folgen dem Plan; die Dateinamen in chapters/de tragen dieselben Nummern. Seitenzahlen verschieben sich mit jeder Revision; die Tabelle wird von toc.py aus dem zusammengestellten Entwurf erzeugt, nicht von Hand gepflegt."), encoding="utf-8")
print("wrote both TOC files")

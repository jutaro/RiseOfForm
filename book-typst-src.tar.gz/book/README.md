# Rise of Form / Werden der Form: Typst book toolchain (adopted 2026-08-25)

Replaces the WeasyPrint pipeline (build_pdf8.py / build_pdf9.py) for the book. The canonical
chapter sources are now the `.typ` files under `chapters/`; the Markdown drafts in the snapshot
are history and are no longer edited.

## Layout
    template.typ            shared styles: Barlow, A4, accent draft line, chapter openers, code, tables
    book-en.typ             assembled English draft (parts, planned-chapter notes, outline)
    book-de.typ             assembled German draft
    chapters/en/NN-slug.typ one file per written chapter, NN = position in the plan v0.56 TOC
    chapters/de/NN-slug.typ German chapters (same numbering)
    fonts/                  Barlow (OFL), the family the old PDFs used; no system fonts needed
    build.py                builds both books and one PDF per chapter, then runs the dash check
    convert.py              the one-off Markdown migration of the chapters (kept for the record)
    papers/<name>-vX.Y.typ  working papers, notes, agenda v0.37, both concordances: self-contained files
    convert_papers.py       the one-off migration of the papers (kept for the record)
    idris.sublime-syntax    Idris2 grammar for ```idris fences, idris.tmTheme the quiet colour theme

## Chapter file conventions
    #import "../../template.typ": *
    = Chapter Title                         (level 1: chapter)
    #draftline[Chapter draft v0.6, ...]     (the accent line under the title)
    #frontnote[...]                         (chapter 1 only: the italic contract note)
    == Section Title                        (level 2: section)
    #strong[Notes and sources.] ...         (notes paragraphs, as before)
    ```                                     (reduction traces, verbatim monospace)

A new chapter: create chapters/en/NN-slug.typ with the header above, add one `#include` line to
book-en.typ under its part, run build.py. A new version: bump the number in the draft line; the
per-chapter PDF name picks it up automatically.

## Setup (fresh sandbox, network on)
    pip install typst --break-system-packages     # Typst 0.15 compiler, bundled, ~30 s
    python3 build.py                              # outputs to /mnt/user-data/outputs
pandoc is only needed for convert.py. pdftotext (poppler) is preinstalled and used by the check.

## Papers
A paper is one file in papers/, starting with the import and `#show: book-setup.with(title: ..., running: ...)`
lines, then `= Title`, `#draftline[Working paper vX.Y, ...]`, `== 1. Section` and so on. Idris blocks are
```idris fences. A new version: copy the file under the new version number and edit; build.py builds
every file in papers/. Literal double hyphens in prose (idris2 --check) must be written `\-\-`; inside
code fences they are fine as they are.

## Rules carried over
- No em or en dashes. Typst turns `--` and `---` into dashes at parse time, so never write two
  hyphens in prose (the table separator in Markdown was the only case; it is gone now).
  build.py extracts the text of every PDF and fails if a dash is found; template.typ additionally
  flattens any dash that reaches layout.
- Language per book: `lang: "en"` / `lang: "de"` in the book files drives hyphenation and quote
  style. Straight quotes in the source are set as ‘ ’ in English and „ “ in German.
- Outputs go to /mnt/user-data/outputs.

## Not yet done
- WeasyPrint is no longer needed for anything; build_pdf8.py and build_pdf9.py are retired.
- German chapters 2, 3, 4 and the Vessel resync (v0.3 -> v0.5) are content work, unchanged.

#import "../../template.typ": *

= The Question
#draftline[Chapter draft v0.4, Project secret3, Row B, August 11, 2026]

Part One built a world from two rules and proved that it can compute anything. This short chapter asks the question that has been waiting since the first page: when you think, is that the same kind of event? It does not answer yet. It clears the table, makes one promise, and puts a coin in your hand. You can walk this gate in one sitting, and should.

== The Question, Received
A commuter stands on a platform, reading the departure board. If the 7:12 is cancelled, she must take the bus. The board says cancelled. She turns toward the bus stop.

Something happened there, between the board and the turn. Two pieces of information met, and a third thing followed from them. Everybody knows this event from the inside; we do it a hundred times a day. Now the question of this whole part, in its human size: is that little event a cousin of the events in Part One? When she concluded, did something happen that is built like a Kestrel firing, like bonds breaking and forming, like one molecule meeting another in the vessel? Or did it happen in a different world altogether, one that merely shares her skull with the first?

Descartes answered: a different world. Two kinds of stuff, matter and mind, with a border between them that no one ever managed to explain. Most people today have not read Descartes, but everyone has inherited a feeling about his border, one of two. Either: thought obviously floats above mere matter. Or: thought is obviously just matter, and the sooner said the better. This chapter asks you to set both feelings down at the gate. Feelings are not findings. And setting down a lifelong certainty, even for the length of one part, is a small act of willingness; it is the only entrance fee this part charges, and nothing in the book has needed it more. Part Two is going to establish something exact instead, and the exact thing is stranger and better than either feeling.

#strong[Notes and sources.] The question is the last sentence of Part One. Descartes, Meditations (1641); the unexplained border is the interaction problem of every philosophy course since.

== One Sentence, Three Speakers
Part One ended with a boast that invites a famous sentence. Everything computable, from two moves: it is a short step to saying the world is a computation. Before this part opens a single door, listen to three people say that exact sentence, because they mean three different things, and half the confusion of a century comes from letting the three blur.

The mathematician says it and means a theorem: every computable process, whatever runs it, has a model in the two moves. Her sentence has a name and a receipt: it is the completeness theorem of chapter two, with its pedigree from Schoenfinkel to Curry. True, proved, and modest. It says something about computable processes. It says nothing about whether the world is one. And notice, for later: of the three speakers, she is the only one whose sentence is a theorem at all.

The physicist says it and means a guess about nature: that the universe, at bottom, really is such a process. That is a genuine conjecture with a genuine literature, and it is open. This book takes no position on it. Not one theorem in the appendix touches it.

The preacher says it and means a creed: that the world is a computation and nothing but, that matter is everything and thought is matter’s noise. Hear the new word: nothing but. No theorem contains it. The mathematics is silent about the word nothing; the creed is a worldview laid on top of the theorem, wearing its clothes.

And the creed has a hole in it, on its own terms, which a philosopher named Hempel pointed out. The creed says: everything is matter. Fine; what is matter? If matter means what today’s physics describes, the creed is false, because today’s physics is incomplete and will be revised. If matter means what some finished future physics will describe, the creed says: everything is whatever we will someday discover. Which says nothing. The word matter, in the creed’s mouth, is a promissory note signed by an unknown hand. And notice that the creed’s oldest form is not academic at all. It is the everyday conviction, taught to everyone by everything, that you are a body and nothing besides; its strength has never been its arguments, only that nobody examines it. Examined, for two sentences, its key word came back unsigned. There is a second, deeper question the creed also skips, why any of the world’s performing is accompanied by experience at all, but that one belongs to Part Three, and its name waits in the notes.

And hear, before we leave the three, the speaker who is missing. A fourth voice could say the same sentence and mean the opposite creed: the world is a computation because the world is thought, mind is all, and matter is its dream. This book keeps company with traditions of exactly that family, and the gate’s knife cuts them no slack: mind-first is also a reading, never a theorem. The mathematics is as silent about nothing-but-mind as it is about nothing-but-matter, and this part will mark its own sympathies with the same ink it just used on the preacher.

So here is the gate’s discipline, and it holds for every page that follows. In this part, theorems get receipts, guesses get labeled as guesses, and creeds get marked as readings. The three speakers never blur again.

#strong[Notes and sources.] The completeness theorem and its pedigree, chapter two. The physicist’s conjecture is the digital physics line, Zuse’s Rechnender Raum (1969), Fredkin, Wolfram, cited and not adjudicated. Hempel’s dilemma after Carl Hempel. The reserved question is the hard problem of consciousness, Chalmers (1995), treated in Part Three and The Reading.

== The Coin
Take a coin out of your pocket and hold it. Heads on one side, tails on the other. The two faces share no feature; a portrait and a number, nothing alike. And you have never for one second doubted that they are a single piece of metal.

Here is the promise of Part Two, in that coin: matter and thought are related like heads and tails. Not two substances with a border problem. Two faces of one metal. And the promise comes with its jewel already in the book. The smallest interesting citizen of Part One was the term S K K. Read its two faces:

```
S K K, read as matter              S K K, read as thought
a molecule in the vessel           the proof that A implies A
three atoms, every bond priced     the law of identity, logic's first certainty
its meetings cost nothing          proved from nothing, no axioms spent
```

One term. The left column is Part One; you have already read it. The right column is Part Two’s territory. And now the sentence this chapter most wants you to hear: neither column is a promise. Each is a theorem, already checked, sitting in this book’s appendix tonight. The left column’s receipt is called skIdentity: run S K K on any citizen, and it hands the citizen back, in two moves, verified. The right column’s receipt is called iTyped: the very same term carries the type A implies A, derived from zero axioms, verified. Two theorems, one subject. For this one small term, the coin is not a metaphor being announced; it is a fact on file. Its matter face and its thought face are both already certified, by the same silent referee, on the same shelf. What the machine room will show is that the jewel is no lucky coin: the whole currency is minted like this, every proof a citizen of the world of moves, every citizen priced. Two zeroes, one on each face, and they are the same zero, stamped on the same coin. When the showing is done, this sentence will have been earned: when a mind reasons correctly, it is doing, structurally, what nature does when it computes. Thinking does not float above the world. The world is not dumb beneath thought. One metal, two faces, and the border Descartes drew runs through neither. Notice what that sentence restores, and in both directions at once. It does not pull thought down into matter, and it does not dissolve matter up into mind; it hands each face back its dignity by making them one metal. The traditions this book walks with have always insisted on exactly this double restoration, against both one-sided comforts: that no thought is idle, every thought an event with consequences in form; and that form is not beneath dignity, not a prison or a punishment but a face of the same coin as spirit. The coin in your hand is that old insistence, minted.

The doors of this part now open in a fixed order, and the order is deliberate: the limit comes before the triumph, so that nobody over-reads the triumph. First, the next chapter, the other side of the coin: the story of the man who mechanized correct reasoning and discovered the one thing the mechanism cannot deliver, which is truth; his lesson, the map perfect about every road and silent about the destination, is this part’s standing conscience. Second, the machine room: the unification performed in the open, propositions becoming types, proofs becoming citizens, and the commuter’s little inference becoming what it always was, an application, the meeting of two terms. Third, thought unbound: thought outgrows every fixed cage built for it, and whatever is left homeless at the end, truth, aboutness, the thinker, is handed, named and unhidden, to Part Three.

#strong[Notes and sources.] The left column is the vessel and price list chapters; the right column’s receipts are skIdentity and iTyped in the appendix; the correspondence to be shown is the line of Curry and Howard, delivered in the machine room. The door order names chapters eight, nine, and ten.

== The Border
One page of honesty before the gate opens, because this part walks close to your inner life, and that is exactly where a book must not cheat. The front note’s contract governs everything that follows, unchanged: where a theorem is claimed, the appendix holds its receipt; where a reading is offered, it is marked, and the sober reading stands beside it at full strength; and no sentence of this part will claim that the mind has been explained, that experience has been captured, or that you are a term.

The part’s whole ambition fits in one sentence: to move the border. Not to erase it; that cannot be honestly done. Not to leave it where Descartes drew it; the theorems no longer permit that. But to move it to its true location, which lies far deeper inside the mind’s country than the modern reader was taught, and not one step deeper than that. Much more of thinking is machinery than you were told. Not all of it. The traditions have their own version of this border, drawn from the far side: what can be taught, they say, is only the removal of obstacles; the destination itself is never taught, only arrived at, and no curriculum, their own included, delivers it. This part’s border is that old line, met from the near side, with receipts. Where it finally comes to rest, Part Three begins.

The first door is a story. In 1879, in Jena, a mapmaker of thought published a little book with an immodest subtitle, and for twenty three years he believed he had caught the whole of reasoning in a net of signs. What happened to him, and what his net actually held, is the other side of the coin.

#strong[Notes and sources.] The front note’s contract. The mapmaker is Frege, Begriffsschrift (1879); his story belongs to the next chapter. This gate carries no stone; gates do not.

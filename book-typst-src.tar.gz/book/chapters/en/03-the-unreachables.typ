#import "../../template.typ": *

= The Unreachables
#draftline[Rise of Form, chapter draft v0.4, Project secret3, Row B, August 11, 2026]

#frontnote[A note before the chapters. This is the interpretation row of the program: a reading offered to everyone, in harmony with a spiritual view of the world and in honest tension with the assumption that matter comes first. Nothing in these pages is a proof of the reading. Wherever a claim is mathematical, it is not merely quotable but checkable: it points to the working papers of the program, where a compiler has verified it. The reading is an invitation. The equations are load-bearing. They are never the same thing, and this book will never pretend they are.]

This chapter is about numbers, and about a kind of stubbornness. The last chapter built everything from two moves and then found the one thing the building could not give us. This chapter stays inside the country of form and finds something almost as strange there: the made world does not obey its maker. We will build numbers from scratch, as trees and as processes, watch a multiplication run to its answer step by step, and meet, with full proofs in hand, the numbers that no multiplication ever reaches. Then we will stand at the edge of the oldest open country in mathematics. Everything difficult will be shown before it is said.

== The Buttons
A child is on the floor with a tin of buttons, arranging. Twelve buttons make a rectangle three ways:

```
2 x 6    * * * * * *      3 x 4    * * * *      and 1 x 12, a single file,
         * * * * * *               * * * *      which she rejects as cheating
                                   * * * *
```

She likes twelve. Then she counts out thirteen and tries again. Two rows leave one sticking out. Three rows, worse. She pushes them around for a while, because thirteen is only one more than twelve and one more should not change everything. It changes everything. There is no rectangle. There was never going to be a rectangle, and this is the important part: the failure is not in her fingers. Give the thirteen buttons to an engineer, a computer, or an angel, and they fail identically, forever. The refusal belongs to the number.

School will later hand her a definition, a prime is a number whose only divisors are one and itself, and the definition is true and strangely bloodless, a bookkeeping phrase for something she met physically on the floor. Here is the same fact said the way her fingers learned it. Multiplication is the arranging move: a times b means a rows of b buttons. Most numbers can be reached by the move: 12 \= 2 x 6 \= 3 x 4, and 35 \= 5 x 7. A prime is a number that the arranging move cannot reach, if we insist, as the child does, that a real arrangement has at least two rows and at least two columns. Not hard to reach. Cannot, ever, from anywhere. In a book about two moves that reach everything, we have just met the numbers that cannot be reached. The rest of the chapter takes that refusal seriously, and it owes the reader the details.

#strong[Notes and sources.] The rectangle picture is ancient; the Greeks called composite numbers plane numbers for exactly this reason. The single file is the trivial factorization 1 x 13, which is why the child is right to call it cheating, and why the definition of prime excludes it.

== The Trees
Now the same story with this program’s own machinery, in full. The working papers behind this book do arithmetic in an unusual dress, and the dress makes the refusal visible, so this section builds the dress from nothing, and the child comes with us: her thirteen buttons are about to become thirteen leaves.

Begin with almost nothing. Take a single leaf, written with a dot, and one way of joining: put two things under a common root. Write the join with brackets, so (x y) is the tree with x on the left branch and y on the right. That is the entire construction kit. Now let the value of a tree be its number of leaves. Then:

```
one = .        two = (. .)        three = (. (. .))  or  ((. .) .)
```

Notice something honest immediately: from three upward, several different trees carry the same number of leaves. Three has two shapes, four has five, and the count of shapes grows fast. So a number is not one tree; it is a family of trees, all with the same leaf count, and when the papers need one official representative they use the right-leaning comb, the shape of three shown first above, extended: each new unit hangs one more leaf on the left of the old comb. Addition, in this world, is almost embarrassingly simple: to add two trees, join them. The leaves of (x y) are the leaves of x plus the leaves of y, by definition. Two joined with three is a five-leaf tree. Done.

Now the move that earns the dress. To multiply tree s by tree t, replace every leaf of s by a complete copy of t. Gardeners call this grafting: t is the scion, planted at every branch tip of s. Watch it once, with F standing for a copy of four, F \= (. (. (. .))):

```
three = (. (. .))
three grafted with four = (F (F F))        leaves: 3 x 4 = 12
```

Three leaves in the stock, each replaced by a four-leaf scion, twelve leaves in the graft. And that is not an accident of the example; it is the first compiled lemma of the papers, called leavesGraft: for all trees s and t, the leaf count of the graft is the leaf count of s times the leaf count of t. Multiplication is grafting, exactly.

Now the child’s discovery becomes a statement about shapes, and we can prove it right here, both directions, in four sentences. Call a tree solid if it is not a graft of two smaller trees, where smaller means at least two leaves each. Theorem A: a number n greater than one is composite exactly when some tree with n leaves fails to be solid. One direction is the leaf arithmetic: a graft of an a-leaf stock and a b-leaf scion has a times b leaves, with a and b at least two, so if some n-leaf tree is a graft, then n \= a x b is composite. The other direction is a construction: if n \= a x b with both factors at least two, take the comb of a and graft the comb of b onto it; the result has n leaves and is visibly a graft. So composite numbers own decomposable trees, and for a prime like thirteen, every tree with thirteen leaves, all 742,900 shapes of them, is solid, because thirteen is not a times b for any honest a and b. Her thirteen buttons were thirteen leaves all along, and every arrangement she tried on the floor was a graft that leaf arithmetic had already forbidden. The papers compile this for all n at once; you have just verified the reasoning for yourself.

So far the numbers have anatomy: a number is a tree, and the comb is its official body. The papers also give them physiology, because this book’s whole world is made of moves: a number must be able to run. Inside the two-move calculus they implement a small rewriting arithmetic with exactly four rules, and the reader should hold one promise while reading them: the trees are not being abandoned. Where they went will be shown the moment the rules are on the table. Write s x for the successor of x, one more than x, and abbreviate s(s(s 0)) as 3 and so on, purely for the eye. The four rules:

```
R1   mul (s m) k  ->  add k (mul m k)      multiplying by one-more: one more k to add
R2   mul 0 k      ->  0                    multiplying by zero: k is erased
R3   add (s a) x  ->  add a (s x)          adding: move one unit across
R4   add 0 x      ->  x                    adding zero: done
```

Read them once slowly. R1 says: m plus one rows of k is one row of k, plus m rows of k. R3 says: to add, hand units across one at a time, like coins pushed over a table. R2 is the only rule in the whole system that throws anything away, the arithmetic face of the K move from the opening chapter; the other three conserve every symbol. One honest note on the dress: in the papers these four rules, the numerals, and everything below are terms of the two-move calculus, so that a rule firing is ultimately shares and drops; the book shows you the arithmetic layer, and the papers carry the encoding and its proofs.

And now, as promised, where the trees went: nowhere. The successor s of the rules is the comb growing by one more leaf. Joining two trees under one root gives their sum at a single stroke; rules R3 and R4 perform the same sum as motion, handing leaves across one at a time until one side stands empty. And R1 is grafting in slow motion. Grafting plants a copy of k at every leaf of m in one gesture; the machine plants the copies one leaf at a time, one row of buttons after another, exactly as the child laid her rectangles. The trees are what the numbers are. The rules are what the numbers do. Anatomy and physiology of one animal, and the papers prove the two never disagree.

Now watch the animal run; this table is the section’s centerpiece. Take mul 2 3, two times three, and fire the rules to the end. On the left of each line stands the value of the whole expression, computed by ordinary arithmetic at every instant, and the reader should watch that column like a hawk, with one question in mind: does the number ever change?

```
value         expression                    rule
  6           mul 2 3
  6           add 3 (mul 1 3)               R1
  6           add 3 (add 3 (mul 0 3))       R1
  6           add 3 (add 3 0)               R2
  6           add 3 (add 2 1)               R3
  6           add 3 (add 1 2)               R3
  6           add 3 (add 0 3)               R3
  6           add 3 3                       R4
  6           add 2 4                       R3
  6           add 1 5                       R3
  6           add 0 6                       R3
  6           6                             R4
```

Eleven rule firings, and the answer is the numeral six. Now look at the value column. It never moved. Every state of the run was worth exactly six, from the first instant, because each of the four rules preserves value: R1 turns (m+1) x k into k + m x k, which is the same number; R3 turns (a+1) + x into a + (x+1), the same number; R2 and R4 likewise. The papers compile this bookkeeping as a family of lemmas, the value ledger, and it is the key to everything, because of what it makes impossible. Suppose some run of a multiplication box, mul m k, in whatever order its rules happened to fire, arrived at a numeral n. The starting value was m times k. Every step preserved value. The value of the numeral n is n. So n equals m times k, with no further argument, and no appeal to how the run went. Arrival fixes identity: if you got there, there was only one there to get.

That is Theorem B of the papers, and it deserves its exact statement. For all m, k, and n: some run takes mul m k to the numeral of n if and only if n \= m x k. The forward direction is a run you can watch, like the one above, and the papers even compile its exact length: the canonical run of mul m k takes m x (k + 2) + 1 steps, a formula called boxLen; check it against the table, m \= 2 and k \= 3 give 2 x 5 + 1 \= 11, as counted. The formula is not symmetric, and the asymmetry is real: mul 2 100 finishes in 205 steps, mul 100 2 in 401, so the schoolteacher’s old advice, put the smaller number first, is a theorem about this machine.

The backward direction is the ledger argument just given, compiled once for all m, k, n, and all run orders, in the arithmetic fragment exactly as the papers state it, and notably without the heavy classical machinery, called confluence, that such uniqueness claims usually lean on; that machinery gets its honest due later in this part, and this proof’s trick was to walk around it.

And now the refusal is a theorem with a name. Restrict the inputs the way the child restricts her rectangles, both factors at least two. Then a prime p is a numeral that no multiplication box ever reaches: for every m and k of at least two, and every possible run, mul m k does not arrive at p, because by Theorem B arriving would mean p \= m x k, and there are no such m and k. That is what prime means in this book. Not divisible-only-by. Unreachable. Thirteen’s character, compiled, quantified over every pair and every order of moves, checked by the same silent checker as everything else here.

#strong[Notes and sources.] The tree numerals, grafting, the lemma leavesGraft, and Theorem A in both directions are in the program’s first working paper. The count of tree shapes is the Catalan numbers; 742,900 is the count for thirteen leaves. The rewriting arithmetic R1 to R4, the value ledger (the invariant family with afUnique), Theorem B in both directions, and the cost formula boxLen are compiled in the shared proof module and reported in the first and second working papers, stated for the arithmetic fragment exactly as given there; the encoding of the whole layer into the two-move calculus is the papers’ construction. The observation that R2 is the system’s only erasing rule, and its kinship with the K move, is the linearity working paper. The papers, not this book, carry the verification.

== The Alphabet of Refusals
Here is where the chapter turns philosophical, and it starts with a confession about chapters one and two. When the two moves were fixed, and the four rules with them, something happened that nobody signed up for. Every prime was fixed. All of them: the primality of thirteen, of the three-hundred-digit primes that guard your bank card, of primes so large no computer built from all the matter there is will ever name them. Settled, that evening in Goettingen, as a side effect. And not only the primes. Consider the sentence: every even number greater than two is the sum of two primes,

```
4 = 2 + 2     6 = 3 + 3     8 = 3 + 5     10 = 3 + 7     100 = 3 + 97     ...
```

Goldbach conjectured it in 1742; it has been checked far beyond a billion billion and proved for no one; and it became true or false, once and for all, the moment the rules were fixed, though nobody knows which. This is the first face of the chapter’s one thought: consequence outruns creation. You cannot make a world without making infinitely more than you meant. Every real promise has this shape, one sentence and a country of unvisited consequences, and you never sign only what you read. The two moves are the purest case on record.

The second face is a paradox, and it rests on the single most important theorem about numbers, so the theorem goes on the page. The fundamental theorem of arithmetic: every number greater than one is a product of primes, in exactly one way apart from order.

```
12 = 2 x 2 x 3        360 = 2 x 2 x 2 x 3 x 3 x 5        13 = 13
```

Read what it says about our refusers. A prime is defined by what cannot be done to it, and the theorem answers: the refusers are the alphabet. Every reachable number is spelled from unreachable ones, and the spelling is unique, so the foundation of the whole numerical world is precisely the set of numbers that declined to be constructed. Character as refusal is not an obstacle here; it is the load-bearing material. One careful sentence under the reader’s contract: the old traditions this book will meet in a later part defined their highest object in exactly this grammar, by refusals alone, not this, not that, a method the theologians call the negative way; the parallel is a shape, noted, and nothing more is claimed from it here. And the refusal is absolute in a way nothing else ever called atomic turned out to be: the chemists’ atom split in 1938, the physicists’ particles keep a busy family tree, and thirteen will not split next century either, for anyone, at any budget, because Theorem B is not an engineering limit.

One demonstration belongs to every reader by inheritance, because it is twenty three centuries old and still the best trick in mathematics. Somebody claims to hold the complete list of primes: p1, p2, up to pr, all of them. Form the number

```
N = (p1 x p2 x ... x pr) + 1
```

Divide N by any prime on the list and the remainder is one, by construction, so no prime on the list divides N. But by the fundamental theorem, N is a product of primes. Those primes, whatever they are, are not on the list. So the list was never complete, and no list ever is. Euclid wrote this down around 300 before our era. In this chapter’s language: the refusers never run out. The alphabet is infinite.

#strong[Notes and sources.] Goldbach’s conjecture is from his 1742 letter to Euler, verified computationally to beyond 4 x 10^18 and open. The fundamental theorem of arithmetic is Euclid, Elements VII and IX in substance, stated and proved in the modern form by Gauss, Disquisitiones Arithmeticae (1801). The infinitude proof is Elements IX.20, given here in full. The chemical atom’s fission is 1938, Hahn and Strassmann. The fixing of all arithmetic facts by the rules is a plain consequence of the definitions, stated without metaphysical decoration.

== The Open Country
And now the honest ending, which is the strangest fact of the four. We possess this world completely. Every rule is on the table, four clauses and two moves, nothing hidden, no experiment pending; this book’s module can check any claim about any particular number to the last move. Total transparency of law. And the pattern of the primes is not known. What is known is the average. Write pi(x) for how many primes there are up to x. In 1792 a fifteen-year-old in Brunswick was given a book of logarithm tables with a list of primes bound into the back, and he read that list the way other boys read adventure stories, counting in idle minutes how the primes thinned as the numbers grew. Gauss guessed the law of the fade from those minutes, and a century later it was proved:

```
pi(x)  is approximately  x / ln x        (the prime number theorem, 1896)
```

Up to a million, about one number in every 13 or so is prime; up to a billion, one in 21; the crowd thins like a slow fade, smooth, law-abiding, almost serene. The individuals are not. Primes cluster and desert. They arrive in twins, pairs at distance two, like 11 and 13, 17 and 19, 101 and 103, and whether the twins go on forever is open after two thousand years of looking. Then came 2013, and Yitang Zhang. Fifty seven years old, a lecturer with no name in the field, a man who had spent years after his doctorate in accounting work and odd jobs, for a while behind the counter of a friend’s sandwich shop, because the academic world had found no place for him. Out of nowhere he submitted a proof that some fixed gap between primes recurs forever, seventy million at first; the proof was checked and found flawless, and the field stood up. A worldwide open collaboration then raced the bound down within months to 246, and there the front line has stood for a decade. The numbers nothing can reach were opened by a man the system could not reach, and if this chapter has a patron saint, it is he. And above the whole field hangs the question Riemann asked in 1859, in eight pages. He studied the function

```
zeta(s) = 1 + 1/2^s + 1/3^s + 1/4^s + ...
```

extended it, by the methods of analysis, across the whole plane of complex numbers, and discovered that the fine rhythm of the primes, every deviation of the crowd from Gauss’s smooth fade, is governed by where this function’s hidden zeros lie. His hypothesis: they all stand on one vertical line. Every zero ever computed, trillions of them, stands exactly there. After a century and a half, with a million-dollar bounty posted, no one can prove it, and the honest gloss is one sentence: the average of the primes obeys a law we can state, and the individuals dance to a music whose score we can define, compute, and not read.

Let the philosophy land plainly, because it completes the chapter’s thought and corrects a possible misreading of the last one. Chapter two found a border of science at the edge of form, and a reader might have concluded that inside the border, at least, everything is tame: give us the rules and we will give you the world. Here is the correction, from the tamest world there is. Even where the rules are completely known, the facts are not exhausted. Knowing how a world is generated and knowing what is in it are different kinds of knowing, and the second does not follow from the first even in arithmetic, where nothing is hidden, nothing is random, and every step is one of four clauses. Mystery is not a symptom of missing information. It survives total information. There is something quietly comforting in that, and it talks directly to the reader’s own life: you can hold every rule of a thing, a game, a language, a person’s stated principles, and the thing can still astonish you tomorrow, legitimately, without one rule being broken. Depth is not always concealment. Sometimes it is just depth.

So the chapter ends at the shore it was always sailing toward. The buttons refused; the refusal, written exactly, became Theorem B; the refusers turned out to be the alphabet; the alphabet turned out to be infinite; and the map of the refusers runs past every horizon anyone has reached, in a sea whose laws are fully written and whose weather no one can predict. The working papers of this program will keep surveying their stretch of coast, theorem by theorem. But it is worth standing here a moment, at the edge of the best-charted ocean in human thought, feeling what every number theorist feels and few say out loud: that the wind off that water is why they went to sea at all. The child with her thirteen buttons has been standing on this shore the whole time. She just had not looked up yet.

#strong[Notes and sources.] The prime number theorem was conjectured by Gauss around 1792 and proved by Hadamard and de la Vallee Poussin in 1896; the densities quoted are 1/ln(10^6) and 1/ln(10^9), rounded. The twin prime conjecture is open; Zhang’s theorem is 2013, and the Polymath collaboration’s bound of 246 is 2014; Zhang’s years outside the academy are as widely reported. Riemann’s memoir is 1859; the series shown converges for s greater than one and is extended by analytic continuation, which is the one technical phrase this chapter asks the reader to take on faith; the hypothesis is a Clay Millennium Problem. The chapter’s compiled anchors remain those of the Trees section; the open country, by definition, has none. And the reader who wants the feeling of this last section in three minutes of music may put on Van Morrison’s Into the Mystic, from 1970; no line of it is quoted here, and none is needed.

#import "../../template.typ": *

= The Machine That Runs Itself
#draftline[Chapter draft v0.5, Project secret3, Row B, August 11, 2026]

This is the last chapter of Part One, and it pays a debt. The vessel ended on a missing resident: nothing in that lawful world carries its own description and acts on it. This chapter builds the missing thing and proves that it works, and it does so in the pleasantest setting the subject has ever had. In 1985 the logician Raymond Smullyan retold our whole calculus as an enchanted forest of birds, in a book called To Mock a Mockingbird, and his forest is not a picture of the two moves; it is the two moves, wearing feathers. We will follow his custom, which is the right one: the forest’s laws are written as small equations, and the equations do the exact work, so that the prose around them can relax. One loan covers the whole chapter: the forest itself, cash value, every bird is a term and calling is application. Nothing will be said under the trees that is not a checked theorem outside them, and the notes hold the receipts.

== The Forest
The custom of the forest is this: when you call the name of a bird y to a bird x, the bird x calls some bird’s name back, and we write the response simply as x y. Two birds side by side on the page mean one conversation: the right one was called to the left one. With that convention, the whole legislation of the forest fits on three lines, and two of the lawgivers are old friends, for Smullyan gave our two moves their bird names. The Kestrel is the dropping move; the Starling is the sharing move; the Mockingbird you have met as the mirror.

```
K x y    =  x            the Kestrel keeps the first and drops the second
S x y z  =  x z (y z)     the Starling hands z, whole, to both x and y
M x      =  x x           the Mockingbird answers as x answers to itself
```

Read the Kestrel’s law aloud once: call a sparrow to the Kestrel, then an owl, and the answer is the sparrow; the owl is gone from the conversation, whole. Read the Starling’s: it takes a task in two parts, x and y, and one bird z, and gives z entire to each part, letting the two responses meet. Everything in this forest, every bird however strange, is built from Kestrels and Starlings alone; that is Part One’s oldest theorem in plumage, and the Mockingbird is our first witness, for M does exactly what S I I does, where I is the bird of the next paragraph.

Here is the pleasure of the notation: you can now prove things by pushing the laws. Try this one before reading on. What does the bird S K K answer, when any bird x is called to it?

```
S K K x  =  K x (K x)  =  x
```

One Starling step, one Kestrel step, and out comes x itself, untouched. The bird S K K answers everything with itself: it is the Identity bird, and you have just built it from the two lawgivers, which is the crown equation of this book’s first chapter wearing feathers.

Now the forest’s first marvel, and it is worth doing slowly, in Smullyan’s own manner. Say that a bird A is fond of a bird B when A answers B with B itself:

```
A B  =  B
```

Claim: in this forest, every bird is fond of some bird. Every bird, no exceptions, however wild its habits. The proof is three lines. Take any bird A. By composition there is a bird C that does A after the Mockingbird, which is to say, C obeys the law C x \= A (M x). Now call C to itself, and push:

```
C C  =  A (M C)  =  A (C C)
```

Read the two ends of the chain: C C equals A called on C C. But that is exactly fondness: the bird C C, offered to A, comes back unchanged. A is fond of C C, and notice what we never used: anything about A. Where there is composition and a mirror, every process whatsoever has a point it leaves in peace. Self-reference, in this forest, is not an accident. It is the climate.

#strong[Notes and sources.] Smullyan, To Mock a Mockingbird (1985); Kestrel, Starling, and Mockingbird are his names, and the fondness argument above is his presentation of the fixed-point theorem of combinatory logic. Compiled anchors: skIdentity for the crown equation, mirror for M as S I I, fondPoint for the marvel.

== The Songs
The birds of this forest can sing, and the songs obey a notation of their own. Fix three notes, once and for all: one note for the Kestrel, one for the Starling, one for the act of joining. Then every bird x has a song, the melody that spells its build joint by joint, and we write the song of x in brackets:

```
[x]   the song of the bird x
```

A child sees at once what a song is not. The song about a hawk frightens nobody; singing of the Kestrel drops nothing. The song is not the bird; it is the bird’s name, set to music. In this forest the child’s observation is two compiled theorems, and they are the two laws of all writing:

```
[x] never calls back                        songs are still birds
[x] = [y]  only when  x = y                 songs never lie
```

The first is the theorem quoteClosed: a song, offered anything, just sits there, a perfectly still bird, all melody and no reply. The second is quoteInj: different birds, different songs, always. And pause on the quiet enormity. A song is itself a bird, built of Kestrels and Starlings like its subject, so the forest now contains a complete songbook of itself, every resident an entry, the entries made of the forest’s own material, and the entries doing nothing at all. A songbook is the stillest thing under the trees. For it to matter, the forest needs what every songbook needs: a bird that can read.

#strong[Notes and sources.] The three notes and the spelling are the working paper A Quoted Alphabet; anchors quote, quoteClosed, quoteInj.

== The Song-Reader
What must a reading bird do? State its job as two laws, for the job is exactly two laws long. Write x -\> y for the forest’s own fact that the bird x, after one call, becomes y.

```
if  x -> y      then   R [x]  =  [y]
if  x rests     then   R [x]  stays silent
```

Sing R the song of any bird, and R sings back the song of what that bird becomes next; and if the sung bird is finished, R does not invent. Feel the severity of the second column: R never touches the birds themselves. It works on melodies alone, and must perform the forest’s whole grammar on music.

Such a bird was raised in four seasons. It learned to hear the Kestrel’s shape inside a song and to sing the survivor; then the Starling’s shape, the harder ear, where it must assemble, note by note, a melody in which the shared bird sounds twice; then to choose between its two ears; and last, since a bird’s next call may lie buried deep in its build, it was knotted through the Mockingbird, the same knot as the marvel above, so that it can pass songs onward to itself, to any depth. The result is a single bird, and the papers call it simT. The forest calls it the Song-Reader. Watch it work once:

```
R [K sparrow owl]  =  [sparrow]
```

Correct, and it never met the sparrow. It read.

Now the receipts, for this is the strongest claim in Part One. Outside the forest stands the referee, the exact mathematical definition of every bird’s next call, and two compiled theorems, simCorrectJ and simCorrectN, say that R and the referee agree: for every bird there is, whenever the referee says it calls, R sings the next state’s song, exactly, and whenever the referee says it rests, R is silent. Sixty two theorems across six papers stand behind that pair. And now the step the whole chapter has climbed toward. R is a bird; therefore R has a song, \[R\]; and the two laws above hold for every bird, this one included:

```
R [R]   reads on, correct, unblinking
```

The interpreter is not a commentary perched outside the forest. The bird that reads the songs has a song, and reads it.

#strong[Notes and sources.] The four seasons are the papers The First Eye, The Second Eye and the Assembler, The Dispatcher, and The Knot, on The Reader’s Engine; anchors readK, readS, rootRead, simT, simCorrectJ, simCorrectN. Outside the trees the same fact has a discoverer and a date, Turing 1936: one machine that reads descriptions can become any machine. The reader of this book carries one in a pocket; every app on it is a song, still until read.

== The Nest-Builder
Now ask the vessel’s question in feathers: could a bird build its own successor? Think it through, and the answer needs exactly three residents. The bird’s song, \[X\], the full melody of its build. A builder, a bird that, sung a song, builds the bird the song names, twig by twig, a Reader whose answers are bodies rather than melodies. And one resident nobody expects, the masterstroke: an echo bird, which repeats any song note for note without hearing what it names, so that the child receives not only a body but the melody for the next body. Song, builder, echo; let the three hold their own song, and the forest has a resident that continues itself.

Our forest owns the song, compiled, and the Reader, compiled and certified. The builder of bodies, in the lawful vessel where every twig is paid for, is an open campaign, said plainly, with one guarantee already signed: by the law of the mint, nothing conjures twigs, so whatever closes the gap will build honestly, paying for every joint out of what it gathers.

Open one window, for one paragraph. This architecture, song, builder, blind echo, was derived on paper by von Neumann in 1948 as the necessary shape of any self-building thing. Five years later, Watson and Crick opened the living cell, and there it stood, clause for clause: a text, a reader that builds what the text names, a copier that never reads what it copies. The fable’s floor plan turned out to be the floor plan of every living thing, including the eyes crossing this sentence. Close the window; the trees continue.

#strong[Notes and sources.] Von Neumann, Hixon Symposium 1948, published 1951; Theory of Self-Reproducing Automata (1966); Watson and Crick, 1953. The builder gap is the vessel chapter’s open campaign; the mint law is stepsNeverMint, the Assembly Ledger paper.

== The Seer and the Song of the Forest
Three times in this book a bird has faced a mirror, and the three lines are worth seeing together:

```
M M  =  M M                          the sterile circle
X X  =  f (X X)  =  f (f (X X)) ...  the knot's ladder
R [R]                                 the word
```

The first is the Mockingbird facing the Mockingbird: push the law once and it returns exactly itself, self-regard answering self-regard, forever, producing nothing; compiled as omegaCycle, and already billed, for this is the resident the price list metered, all upkeep, no yield. The second is the same circle carrying a worker f through it once per round, self-reference that lifts another bird, rung by rung; compiled as yUnfolds, and every mill in this book turns on it. The third is the Song-Reader with its own song in its ear: self-reference through description, the forest holding its own melody and acting on it. Sterile, fruitful, creative: self-reference is not one thing but a scale, and the forest sings all three notes with receipts.

Now the rim, without flinching. Could the forest hold a Seer, a bird F that foretells every fate?

```
F [x]  =  "rests"      if x comes to rest
F [x]  =  "never"      if x never does
```

Suppose it could, and compose the Contrary Bird N, which asks the Seer and does the opposite: N, sung a song, circles forever if F says rests, and falls silent if F says never. The Contrary Bird is a bird, so it has a song. Sing it its own:

```
N [N]   circles  if F says it rests;   rests  if F says it never does
```

Either way the Seer is wrong about N, so there is no Seer, not here, not in any forest that can tie the knot. Turing proved it in 1936, and it carries an old warning in new feathers: to judge every story, a bird would have to see the end of every story, and no resident of any forest sees that, its own included. Two quiet stones beside it. All flight paths that arrive, arrive at the same tree, which is the classical confluence theorem, closing a door the unreachables left ajar. And the gate from chapter two, standing untouched among the trees: the Song-Reader hears every song and understands none. It knows every shape in the music and no meaning; performing a melody is not comprehending it; nothing in this forest opens an inside.

And so, once, under the contract, the stone, with two faces. The first: in the beginning was the Word, and all things were made through it. Whatever else that old sentence is, it is a claim about a world and its description, and this chapter, for the first time, has a compiled sentence to set beside it: the forest holds its own song, and the song works. The description is not a caption beneath the trees, added by an outside author; it is a resident, made of Kestrels and Starlings like everything it describes, and reading it is one of the things the forest does. Creation, in this small cosmos, needs no hand reaching in past the canopy: the forest sings itself, and listens, and acts. The second face looks at the gate. If awareness were a resident of the forest, it would have a song, and the songbook would carry its entry; the songbook is complete, nothing in it is missing, and no entry is awareness. The traditions this book walks with have always said why in one sentence: the knower was never among the known. This book does not prove that sentence, for no book of theorems could; it notes, with receipts, that the forest is exactly as complete, and exactly as silent, as the sentence predicts. Beside both faces, at full strength, the sober reading: what was built is a self-interpreter, a known species since 1936, in a very small calculus; the forest is a manner of speaking; every rhyme here is detachable. The theorems hold in both registers, and that is why they were worth a Part.

Part One closes here. Two moves, their prices, their numbers, their unreachables, a lawful vessel, and a forest that sings its whole story, its own singer included, and performs what it sings. The next Part opens with the question the trees have been raising since the first page. The forest is mapped, every bird and every song. Is thinking somewhere among the birds? Or is the map of the forest in the hand of something no song names?

#strong[Notes and sources.] omegaCycle, yKnot, yUnfolds are the opening chapter’s; the sterile circle’s bill is the price list’s portrait; the ladder equation is yUnfolds’ statement. Turing (1936, corrected 1937) and Church and Rosser (1936), cited classical; Seer and Contrary Bird are this chapter’s forest dress for the diagonal, not Smullyan’s terms. The gate is the Empty Symbol section of chapter two. John’s opening is reported as the tradition’s voice; the second face’s sentence is reported, not claimed as theorem; the front note governs both. The chapter’s one loan, the forest, is repaid: every bird was a term, every call an application, every song a quotation.

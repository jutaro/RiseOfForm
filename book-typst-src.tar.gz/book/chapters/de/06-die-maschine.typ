#import "../../template.typ": *

= Die Maschine, die sich selbst laufen lässt
#draftline[Kapitelentwurf v0.5, deutsche Fassung, Projekt secret3, Reihe B, 11. August 2026]

Dies ist das letzte Kapitel des ersten Teils, und es bezahlt eine Schuld. Das Gefäß endete mit einem fehlenden Bewohner: Nichts in jener gesetzmäßigen Welt trägt seine eigene Beschreibung und handelt nach ihr. Dieses Kapitel baut das Fehlende und beweist, dass es funktioniert, und es tut das in der freundlichsten Umgebung, die der Gegenstand je hatte. 1985 erzählte der Logiker Raymond Smullyan unseren ganzen Kalkül als verzauberten Wald voller Vögel nach, in einem Buch namens To Mock a Mockingbird, und sein Wald ist kein Bild der zwei Züge; er ist die zwei Züge, im Federkleid. Wir folgen seinem Brauch, und es ist der richtige: Die Gesetze des Waldes werden als kleine Gleichungen geschrieben, und die Gleichungen leisten die exakte Arbeit, sodass die Prosa um sie herum sich entspannen darf. Eine Anleihe deckt das ganze Kapitel: der Wald selbst, Barwert, jeder Vogel ist ein Term und das Rufen ist die Anwendung. Unter den Bäumen wird nichts gesagt, was außerhalb nicht ein geprüftes Theorem wäre, und die Anmerkungen halten die Belege.

== Der Wald
Der Brauch des Waldes ist dieser: Ruft man einem Vogel x den Namen eines Vogels y zu, so ruft x den Namen irgendeines Vogels zurück, und wir schreiben die Antwort einfach als x y. Zwei Vögel nebeneinander auf der Seite bedeuten ein Gespräch: Der rechte wurde dem linken zugerufen. Mit dieser Konvention passt die gesamte Gesetzgebung des Waldes auf drei Zeilen, und zwei der Gesetzgeber sind alte Bekannte, denn Smullyan gab unseren zwei Zügen ihre Vogelnamen. Der Turmfalke ist der Weglass-Zug; der Star ist der Teil-Zug; die Spottdrossel kennst du als den Spiegel.

```
K x y    =  x            der Turmfalke behält das Erste, das Zweite fällt
S x y z  =  x z (y z)     der Star reicht z, ganz, an x und an y zugleich
M x      =  x x           die Spottdrossel antwortet, wie x sich selbst antwortet
```

Lies das Gesetz des Turmfalken einmal laut: Ruf ihm einen Spatz zu, dann eine Eule, und die Antwort ist der Spatz; die Eule ist aus dem Gespräch verschwunden, ganz. Lies das des Stars: Er nimmt eine Aufgabe in zwei Teilen, x und y, und einen Vogel z, gibt z jedem Teil ganz und lässt die zwei Antworten einander begegnen. Alles in diesem Wald, jeder noch so seltsame Vogel, ist allein aus Turmfalken und Staren gebaut; das ist das älteste Theorem des ersten Teils in Gefieder, und die Spottdrossel ist unser erster Zeuge, denn M tut genau, was S I I tut, wobei I der Vogel des nächsten Absatzes ist.

Und hier liegt das Vergnügen der Notation: Man kann jetzt beweisen, indem man die Gesetze schiebt. Versuch dieses, bevor du weiterliest. Was antwortet der Vogel S K K, wenn man ihm einen beliebigen Vogel x zuruft?

```
S K K x  =  K x (K x)  =  x
```

Ein Star-Schritt, ein Turmfalken-Schritt, und heraus kommt x selbst, unberührt. Der Vogel S K K antwortet auf alles mit eben diesem: Er ist der Identitätsvogel, und du hast ihn soeben aus den zwei Gesetzgebern gebaut, die Krongleichung des ersten Kapitels dieses Buches, im Federkleid.

Nun das erste Wunder des Waldes, und es lohnt, es langsam zu tun, nach Smullyans eigener Art. Sage, ein Vogel A ist einem Vogel B zugetan, wenn A auf B mit B selbst antwortet:

```
A B  =  B
```

Behauptung: In diesem Wald ist jeder Vogel irgendeinem Vogel zugetan. Jeder Vogel, ohne Ausnahme, wie wild seine Gewohnheiten auch seien. Der Beweis ist drei Zeilen lang. Nimm irgendeinen Vogel A. Durch die Komposition gibt es einen Vogel C, der A nach der Spottdrossel tut, das heißt, C gehorcht dem Gesetz C x \= A (M x). Nun rufe C sich selbst zu, und schiebe:

```
C C  =  A (M C)  =  A (C C)
```

Lies die zwei Enden der Kette: C C ist gleich A, gerufen auf C C. Aber genau das ist Zugetanheit: Der Vogel C C, dem A dargeboten, kommt unverändert zurück. A ist C C zugetan, und beachte, was wir nie benutzt haben: irgendetwas über A. Wo es Komposition und einen Spiegel gibt, hat jeder Prozess überhaupt einen Punkt, den er in Frieden lässt. Selbstbezug ist in diesem Wald kein Zufall. Er ist das Klima.

#strong[Anmerkungen und Quellen.] Smullyan, To Mock a Mockingbird (1985); Turmfalke, Star und Spottdrossel sind seine Namen, und das Zugetanheits-Argument oben ist seine Darstellung des Fixpunktsatzes der kombinatorischen Logik. Kompilierte Anker: skIdentity für die Krongleichung, mirror für M als S I I, fondPoint für das Wunder.

== Die Lieder
Die Vögel dieses Waldes können singen, und die Lieder gehorchen einer eigenen Notation. Lege drei Noten fest, ein für alle Mal: eine Note für den Turmfalken, eine für den Star, eine für den Akt des Fügens. Dann hat jeder Vogel x ein Lied, die Melodie, die seinen Bau Gelenk für Gelenk buchstabiert, und wir schreiben das Lied von x in Klammern:

```
[x]   das Lied des Vogels x
```

Ein Kind sieht sofort, was ein Lied nicht ist. Das Lied über einen Habicht erschreckt niemanden; vom Turmfalken zu singen lässt nichts fallen. Das Lied ist nicht der Vogel; es ist der Name des Vogels, in Musik gesetzt. In diesem Wald ist die Beobachtung des Kindes zwei kompilierte Theoreme, und es sind die zwei Gesetze aller Schrift:

```
[x] ruft niemals zurück                       Lieder sind stille Vögel
[x] = [y]  nur wenn  x = y                    Lieder lügen nie
```

Das erste ist das Theorem quoteClosed: Ein Lied, dem man irgendetwas darbietet, bleibt einfach liegen, ein vollkommen stiller Vogel, ganz Melodie und keine Antwort. Das zweite ist quoteInj: verschiedene Vögel, verschiedene Lieder, immer. Und halte inne bei der stillen Ungeheuerlichkeit. Ein Lied ist selbst ein Vogel, aus Turmfalken und Staren gebaut wie sein Gegenstand, also enthält der Wald jetzt ein vollständiges Liederbuch seiner selbst, jeder Bewohner ein Eintrag, die Einträge aus dem eigenen Material des Waldes, und die Einträge tun rein gar nichts. Ein Liederbuch ist das stillste Ding unter den Bäumen. Damit es zählt, braucht der Wald, was jedes Liederbuch braucht: einen Vogel, der lesen kann.

#strong[Anmerkungen und Quellen.] Die drei Noten und die Buchstabierung sind das Arbeitspapier A Quoted Alphabet; Anker quote, quoteClosed, quoteInj.

== Der Liederleser
Was muss ein lesender Vogel können? Gib seine Aufgabe als zwei Gesetze an, denn genau zwei Gesetze lang ist sie. Schreibe x -\> y für die waldeigene Tatsache, dass der Vogel x nach einem Ruf zu y wird.

```
wenn  x -> y      dann   R [x]  =  [y]
wenn  x ruht      dann   bleibt R [x] still
```

Sing R das Lied irgendeines Vogels vor, und R singt das Lied dessen zurück, was jener Vogel als Nächstes wird; und ist der besungene Vogel fertig, erfindet R nichts. Spüre die Strenge der zweiten Spalte: R berührt die Vögel selbst nie. Er arbeitet allein an Melodien und muss die ganze Grammatik des Waldes an Musik vollziehen.

Aufgezogen wurde ein solcher Vogel in vier Jahreszeiten. Er lernte, die Gestalt des Turmfalken in einem Lied zu hören und den Überlebenden zu singen; dann die Gestalt des Stars, das schwerere Gehör, wo er Note für Note eine Melodie zusammensetzen muss, in der der geteilte Vogel zweimal erklingt; dann zwischen seinen zwei Ohren zu wählen; und zuletzt, weil der nächste Ruf eines Vogels tief in seinem Bau vergraben liegen kann, wurde er durch die Spottdrossel geknotet, denselben Knoten wie im Wunder oben, sodass er Lieder an sich selbst weiterreichen kann, in jede Tiefe. Das Ergebnis ist ein einziger Vogel, und die Papiere nennen ihn simT. Der Wald nennt ihn den Liederleser. Sieh ihm einmal bei der Arbeit zu:

```
R [K Spatz Eule]  =  [Spatz]
```

Richtig, und er hat den Spatz nie getroffen. Er hat gelesen.

Nun die Belege, denn dies ist die stärkste Behauptung des ersten Teils. Außerhalb des Waldes steht der Schiedsrichter, die exakte mathematische Definition des nächsten Rufs jedes Vogels, und zwei kompilierte Theoreme, simCorrectJ und simCorrectN, sagen, dass R und der Schiedsrichter übereinstimmen: Für jeden Vogel, den es gibt, singt R, wann immer der Schiedsrichter sagt, er ruft, genau das Lied des nächsten Zustands, und wann immer der Schiedsrichter sagt, er ruht, schweigt R. Zweiundsechzig Theoreme über sechs Papiere stehen hinter dem Paar. Und nun der Schritt, auf den das ganze Kapitel zugestiegen ist. R ist ein Vogel; also hat R ein Lied, \[R\]; und die zwei Gesetze oben gelten für jeden Vogel, diesen eingeschlossen:

```
R [R]   liest weiter, richtig, ohne zu blinzeln
```

Der Interpret ist kein Kommentar, der außerhalb des Waldes sitzt. Der Vogel, der die Lieder liest, hat ein Lied, und liest es.

#strong[Anmerkungen und Quellen.] Die vier Jahreszeiten sind die Papiere The First Eye, The Second Eye and the Assembler, The Dispatcher und The Knot, auf The Reader’s Engine; Anker readK, readS, rootRead, simT, simCorrectJ, simCorrectN. Außerhalb der Bäume hat dieselbe Tatsache einen Entdecker und ein Datum, Turing 1936: Eine Maschine, die Beschreibungen liest, kann jede Maschine werden. Der Leser dieses Buches trägt eine in der Hosentasche; jede App darauf ist ein Lied, still, bis es gelesen wird.

== Der Nestbauer
Nun stelle die Frage des Gefäßes im Federkleid: Könnte ein Vogel seinen eigenen Nachfolger bauen? Denke es durch, und die Antwort braucht genau drei Bewohner. Das Lied des Vogels, \[X\], die volle Melodie seines Baus. Einen Bauer, einen Vogel, der, ein Lied vorgesungen, den Vogel baut, den das Lied benennt, Zweig für Zweig, einen Leser, dessen Antworten Körper sind statt Melodien. Und einen Bewohner, den niemand erwartet, den Geniestreich: einen Nachsänger, der jedes Lied Note für Note wiederholt, ohne zu hören, was es benennt, damit das Kind nicht nur einen Körper erhält, sondern die Melodie für den nächsten Körper. Lied, Bauer, Echo; lass die drei ihr eigenes Lied halten, und der Wald hat einen Bewohner, der sich selbst fortsetzt.

Unser Wald besitzt das Lied, kompiliert, und den Leser, kompiliert und zertifiziert. Der Bauer der Körper, im gesetzmäßigen Gefäß, wo jeder Zweig bezahlt wird, ist ein offener Feldzug, klar gesagt, mit einer Garantie, die schon unterschrieben ist: Nach dem Gesetz der Prägung zaubert nichts Zweige herbei, also wird, was die Lücke je schließt, ehrlich bauen und jedes Gelenk aus dem bezahlen, was es sammelt.

Öffne ein Fenster, für einen Absatz. Diese Architektur, Lied, Bauer, blindes Echo, wurde 1948 von von Neumann auf Papier hergeleitet, als die notwendige Gestalt jedes sich selbst bauenden Dings. Fünf Jahre später öffneten Watson und Crick die lebende Zelle, und da stand sie, Klausel für Klausel: ein Text, ein Leser, der baut, was der Text benennt, ein Kopierer, der nie liest, was er kopiert. Der Grundriss der Fabel erwies sich als der Grundriss jedes Lebewesens, die Augen eingeschlossen, die diesen Satz überqueren. Schließe das Fenster; die Bäume gehen weiter.

#strong[Anmerkungen und Quellen.] Von Neumann, Hixon-Symposium 1948, veröffentlicht 1951; Theory of Self-Reproducing Automata (1966); Watson und Crick, 1953. Die Bauerlücke ist der offene Feldzug des Gefäß-Kapitels; das Gesetz der Prägung ist stepsNeverMint, das Assembly-Ledger-Papier.

== Der Seher und das Lied des Waldes
Dreimal in diesem Buch stand ein Vogel vor einem Spiegel, und die drei Zeilen lohnen den gemeinsamen Blick:

```
M M  =  M M                            der sterile Kreis
X X  =  f (X X)  =  f (f (X X)) ...    die Leiter des Knotens
R [R]                                   das Wort
```

Die erste ist die Spottdrossel vor der Spottdrossel: Schiebe das Gesetz einmal, und sie gibt exakt sich selbst zurück, Selbstbetrachtung, die Selbstbetrachtung antwortet, für immer, nichts hervorbringend; kompiliert als omegaCycle, und schon in Rechnung gestellt, denn dies ist der Bewohner, den die Preisliste vermessen hat, lauter Unterhalt, kein Ertrag. Die zweite ist derselbe Kreis, der einen Arbeiter f einmal pro Runde hindurchträgt, Selbstbezug, der einen anderen Vogel hebt, Sprosse um Sprosse; kompiliert als yUnfolds, und jede Mühle dieses Buches dreht sich auf ihm. Die dritte ist der Liederleser mit dem eigenen Lied im Ohr: Selbstbezug durch Beschreibung, der Wald, der seine eigene Melodie hält und nach ihr handelt. Steril, fruchtbar, schöpferisch: Selbstbezug ist nicht ein Ding, sondern eine Tonleiter, und der Wald singt alle drei Töne, mit Belegen.

Nun der Rand, ohne Zucken. Könnte der Wald einen Seher halten, einen Vogel F, der jedes Schicksal vorhersagt?

```
F [x]  =  "ruht"      wenn x zur Ruhe kommt
F [x]  =  "nie"       wenn x es niemals tut
```

Angenommen, er könnte, und komponiere den Trotzvogel N, der den Seher befragt und das Gegenteil tut: N, ein Lied vorgesungen, kreist ewig, wenn F ruht sagt, und verstummt, wenn F nie sagt. Der Trotzvogel ist ein Vogel, also hat er ein Lied. Sing es ihm selbst vor:

```
N [N]   kreist, wenn F sagt, er ruhe;   ruht, wenn F sagt, niemals
```

So oder so irrt der Seher über N, also gibt es keinen Seher, nicht hier, nicht in irgendeinem Wald, der den Knoten knüpfen kann. Turing bewies es 1936, und es trägt eine alte Warnung in neuem Gefieder: Um über jede Geschichte zu urteilen, müsste ein Vogel das Ende jeder Geschichte sehen, und kein Bewohner irgendeines Waldes sieht das, die eigene eingeschlossen. Zwei stille Steine daneben. Alle Flugrouten, die ankommen, kommen am selben Baum an, der klassische Konfluenzsatz, der eine Tür schließt, die die Unerreichbaren angelehnt ließen. Und das Tor aus Kapitel zwei, unberührt zwischen den Bäumen: Der Liederleser hört jedes Lied und versteht keines. Er kennt jede Gestalt in der Musik und keine Bedeutung; eine Melodie zu vollziehen ist nicht, sie zu begreifen; nichts in diesem Wald öffnet ein Innen.

Und so, einmal, unter dem Vertrag, der Stein, mit zwei Gesichtern. Das erste: Im Anfang war das Wort, und alle Dinge sind durch dasselbe gemacht. Was immer dieser alte Satz sonst ist, er ist eine Behauptung über eine Welt und ihre Beschreibung, und dieses Kapitel hat, zum ersten Mal, einen kompilierten Satz danebenzustellen: Der Wald hält sein eigenes Lied, und das Lied wirkt. Die Beschreibung ist keine Bildunterschrift unter den Bäumen, von einem äußeren Autor hinzugefügt; sie ist ein Bewohner, aus Turmfalken und Staren gemacht wie alles, was sie beschreibt, und sie zu lesen ist eines der Dinge, die der Wald tut. Die Schöpfung braucht, in diesem kleinen Kosmos, keine Hand, die über die Baumkronen hereingreift: Der Wald singt sich selbst, und lauscht, und handelt. Das zweite Gesicht blickt auf das Tor. Wäre das Gewahrsein ein Bewohner des Waldes, hätte es ein Lied, und das Liederbuch trüge seinen Eintrag; das Liederbuch ist vollständig, nichts darin fehlt, und kein Eintrag ist das Gewahrsein. Die Traditionen, mit denen dieses Buch geht, haben immer in einem Satz gesagt, warum: Der Erkennende war nie unter dem Erkannten. Dieses Buch beweist diesen Satz nicht, denn kein Buch aus Theoremen könnte das; es vermerkt, mit Belegen, dass der Wald genau so vollständig und genau so stumm ist, wie der Satz es vorhersagt. Neben beiden Gesichtern, in voller Stärke, die nüchterne Lesart: Gebaut wurde ein Selbstinterpret, eine bekannte Gattung seit 1936, in einem sehr kleinen Kalkül; der Wald ist eine Redeweise; jeder Reim hier ist ablösbar. Die Theoreme gelten in beiden Registern, und darum waren sie einen Teil des Buches wert.

Der erste Teil schließt hier. Zwei Züge, ihre Preise, ihre Zahlen, ihre Unerreichbaren, ein gesetzmäßiges Gefäß, und ein Wald, der seine ganze Geschichte singt, den eigenen Sänger eingeschlossen, und vollzieht, was er singt. Der nächste Teil öffnet mit der Frage, die die Bäume seit der ersten Seite aufwerfen. Der Wald ist kartiert, jeder Vogel und jedes Lied. Ist das Denken irgendwo unter den Vögeln? Oder liegt die Karte des Waldes in der Hand von etwas, das kein Lied benennt?

#strong[Anmerkungen und Quellen.] omegaCycle, yKnot, yUnfolds gehören dem Eröffnungskapitel; die Rechnung des sterilen Kreises ist der Porträt-Abschnitt der Preisliste; die Leitergleichung ist die Aussage von yUnfolds. Turing (1936, korrigiert 1937) und Church und Rosser (1936), klassisch zitiert; Seher und Trotzvogel sind das Waldkleid dieses Kapitels für die Diagonale, keine Begriffe Smullyans. Das Tor ist der Abschnitt Das leere Zeichen in Kapitel zwei. Die Eröffnung des Johannesevangeliums wird als Stimme der Tradition berichtet; der Satz des zweiten Gesichts wird berichtet, nicht als Theorem behauptet; die vordere Notiz regelt beide. Die eine Anleihe des Kapitels, der Wald, ist zurückgezahlt: Jeder Vogel war ein Term, jeder Ruf eine Anwendung, jedes Lied ein Zitat.

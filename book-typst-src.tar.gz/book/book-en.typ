#import "template.typ": *

#show: book-setup.with(title: "Rise of Form", lang: "en", running: "Rise of Form, assembled draft")

#titlepage("Rise of Form", "Assembled chapter drafts, table of contents per plan v0.56", "Project secret3, Row B. Nine of sixteen chapters written. Chapters marked planned are not yet drafted.")

#outline(title: "Contents", depth: 1)

#let part(title, note) = {
  pagebreak(weak: true)
  v(5cm)
  text(size: 12pt, fill: accent, weight: "semibold")[#title]
  v(0.3cm)
  text(size: 10pt, fill: mute)[#note]
}

#part("Part One, Form: The Country of Form", "Computation only: machinery, cost, number, worlds.")
#include "chapters/en/01-two-moves.typ"
#include "chapters/en/02-everything-from-two.typ"
#include "chapters/en/03-the-unreachables.typ"
#include "chapters/en/04-the-price-list.typ"
#include "chapters/en/05-the-vessel.typ"
#include "chapters/en/06-the-machine-that-runs-itself.typ"

#part("Part Two, Thought", "The Question, The Other Side of the Coin, The Machine Room (planned), Thought Unbound (planned).")
#include "chapters/en/07-the-question.typ"
#include "chapters/en/08-the-other-side-of-the-coin.typ"

#part("Part Three, Consciousness", "The Witness, The Receiver, The Unfinished Physics: all planned.")

#part("Finale", "Spirit, Soul, and Form (planned); The Two Courses (planned); The Reading.")
#include "chapters/en/16-the-reading.typ"

#!/usr/bin/env python3
"""One-off migration of the Markdown chapter drafts to native Typst sources.

Usage: python3 convert.py <snapshot-dir>
Writes chapters/en/NN-slug.typ and chapters/de/NN-slug.typ.
After this run the .typ files are the canonical sources; the .md files are history.
"""
import re, subprocess, sys, pathlib

SNAP = pathlib.Path(sys.argv[1])
HERE = pathlib.Path(__file__).parent

EN = [
    ("01", "two-moves", "rise-of-form-chapter-two-moves-v0.12.md"),
    ("02", "everything-from-two", "rise-of-form-chapter-everything-from-two-v0.6.md"),
    ("03", "the-unreachables", "rise-of-form-chapter-the-unreachables-v0.4.md"),
    ("04", "the-price-list", "rise-of-form-chapter-the-price-list-v0.1.md"),
    ("05", "the-vessel", "rise-of-form-chapter-the-vessel-v0.5.md"),
    ("06", "the-machine-that-runs-itself", "rise-of-form-chapter-the-machine-that-runs-itself-v0.5.md"),
    ("07", "the-question", "rise-of-form-chapter-the-question-v0.4.md"),
    ("08", "the-other-side-of-the-coin", "rise-of-form-chapter-the-other-side-of-the-coin-v0.10.md"),
    ("16", "the-reading", "rise-of-form-chapter-the-reading-v0.2.md"),
]
DE = [
    ("01", "zwei-zuege", "werden-der-form-kapitel-zwei-zuege-v0.12-de.md"),
    ("05", "das-gefaess", "werden-der-form-kapitel-das-gefaess-v0.3-de.md"),
    ("06", "die-maschine", "werden-der-form-kapitel-die-maschine-v0.5-de.md"),
    ("07", "die-frage", "werden-der-form-kapitel-die-frage-v0.4-de.md"),
    ("08", "die-andere-seite-der-muenze", "werden-der-form-kapitel-die-andere-seite-der-muenze-v0.10-de.md"),
    ("16", "die-lesart", "werden-der-form-kapitel-die-lesart-v0.2-de.md"),
]

def convert(src: pathlib.Path) -> str:
    typ = subprocess.run(
        ["pandoc", "--wrap=none", "-f", "markdown", "-t", "typst", str(src)],
        check=True, capture_output=True, text=True).stdout
    lines = typ.split("\n")
    out = []
    i = 0
    seen_draft = False
    while i < len(lines):
        ln = lines[i]
        # drop pandoc's auto labels after headings
        if re.fullmatch(r"<[^>]+>", ln.strip()):
            i += 1; continue
        # chapter title: strip the book-title prefix
        if ln.startswith("= "):
            ln = re.sub(r"^= (Rise of Form|Werden der Form): ", "= ", ln)
        # sections: pandoc maps H3 to ===, we want level 2
        elif ln.startswith("=== "):
            ln = "== " + ln[4:]
        # draft line
        if not seen_draft and out and out[-1].startswith("= ") and re.fullmatch(r"#strong\[[^\]]*\];?", ln.strip()):
            ln = "#draftline[" + ln.strip()[len("#strong["):-1] + "]"
            seen_draft = True
        # the front note (a whole paragraph in #emph, right after the draft line)
        elif seen_draft and re.fullmatch(r"#emph\[.*\];?", ln.strip()) and len(out) >= 2 and out[-2].startswith("#draftline"):
            ln = "#frontnote[" + ln.strip()[len("#emph["):-1] + "]"
        out.append(ln)
        i += 1
    body = "\n".join(out).strip() + "\n"
    return '#import "../../template.typ": *\n\n' + body

def check_dashes(text: str, name: str):
    # forbid -- / --- outside raw blocks (Typst would turn them into dashes)
    in_raw = False
    for n, ln in enumerate(text.split("\n"), 1):
        if ln.startswith("```"):
            in_raw = not in_raw; continue
        if not in_raw and "--" in ln:
            raise SystemExit(f"{name}:{n}: double hyphen outside raw block: {ln[:80]}")
        for ch in "\u2013\u2014":
            if ch in ln:
                raise SystemExit(f"{name}:{n}: literal dash character")

for lang, table in (("en", EN), ("de", DE)):
    d = HERE / "chapters" / lang
    d.mkdir(parents=True, exist_ok=True)
    for num, slug, md in table:
        text = convert(SNAP / md)
        if lang == "de":
            text = text.replace("\u201d", "\u201c")  # pandoc closes German quotes with the English mark
        name = f"{num}-{slug}.typ"
        check_dashes(text, name)
        (d / name).write_text(text, encoding="utf-8")
        print("wrote", lang, name, len(text.split()), "words")

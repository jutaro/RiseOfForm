#import "template.typ": *

#show: book-setup.with(title: "Werden der Form", lang: "de", running: "Werden der Form, zusammengestellter Entwurf")

#titlepage("Werden der Form", "Zusammengestellte Kapitelentwürfe, Inhaltsverzeichnis nach Plan v0.56", "Projekt secret3, Reihe B. Deutsche Fassung: sechs Kapitel übersetzt; Kapitel 2, 3, 4 stehen aus, das Gefäß wartet auf den Abgleich mit v0.5.")

#outline(title: "Inhalt", depth: 1)

#let part(title, note) = {
  pagebreak(weak: true)
  v(5cm)
  text(size: 12pt, fill: accent, weight: "semibold")[#title]
  v(0.3cm)
  text(size: 10pt, fill: mute)[#note]
}

#part("Erster Teil, Form: Das Land der Form", "Kapitel 2, 3 und 4 (Alles aus Zwei, Die Unerreichbaren, Die Preisliste) noch nicht übersetzt.")
#include "chapters/de/01-zwei-zuege.typ"
#include "chapters/de/05-das-gefaess.typ"
#include "chapters/de/06-die-maschine.typ"

#part("Zweiter Teil, Denken", "Der Maschinenraum und Denken entfesselt: geplant.")
#include "chapters/de/07-die-frage.typ"
#include "chapters/de/08-die-andere-seite-der-muenze.typ"

#part("Dritter Teil, Bewusstsein", "Der Zeuge, Der Empfänger, Die unvollendete Physik: geplant.")

#part("Finale", "Geist, Seele und Form (geplant); Die zwei Kurse (geplant); Die Lesart.")
#include "chapters/de/16-die-lesart.typ"

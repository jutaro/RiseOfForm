#!/usr/bin/env python3
"""One-off migration of the working papers, notes, agenda and concordances to Typst.
Usage: python3 convert_papers.py <snapshot-dir>
Takes the latest version of each paper family; writes papers/<name>-vX.Y.typ, self-contained.
"""
import re, subprocess, sys, pathlib

SNAP = pathlib.Path(sys.argv[1]); HERE = pathlib.Path(__file__).parent
OUT = HERE / "papers"; OUT.mkdir(exist_ok=True)
SKIP = re.compile(r"chapter|kapitel|book-plan|draft-v|deferred|toc-proposal|section-the")

latest = {}
for f in SNAP.glob("*.md"):
    if SKIP.search(f.name): continue
    m = re.match(r"(.*)-v(\d+)\.(\d+)\.md", f.name)
    if not m: continue
    v = (int(m.group(2)), int(m.group(3)))
    if m.group(1) not in latest or v > latest[m.group(1)][0]:
        latest[m.group(1)] = (v, f)

def convert(src):
    typ = subprocess.run(["pandoc", "--wrap=none", "-f", "markdown-smart-citations", "-t", "typst", str(src)],
                         check=True, capture_output=True, text=True).stdout
    out, in_raw, seen_draft = [], False, False
    for ln in typ.split("\n"):
        if ln.startswith("```"):
            in_raw = not in_raw; out.append(ln); continue
        if in_raw:
            out.append(ln); continue
        if re.fullmatch(r"<[^>]+>", ln.strip()):
            continue
        ln = ln.replace('\\"', '"').replace("\\'", "'")  # let Typst set the quotes
        ln = ln.replace("--", "\\-\\-")        # keep literal double hyphens (idris2 --check)
        if not seen_draft and out and out[-1].startswith("= ") and re.fullmatch(r"#strong\[[^\]]*\];?", ln.strip()):
            ln = "#draftline[" + ln.strip()[len("#strong["):-1] + "]"; seen_draft = True
        out.append(ln)
    return "\n".join(out).strip() + "\n"

def check(text, name):
    in_raw = False
    for n, ln in enumerate(text.split("\n"), 1):
        if ln.startswith("```"): in_raw = not in_raw; continue
        if in_raw: continue
        if re.search(r"(?<!\\)-(?<!\\-)-", ln.replace("\\-\\-", "")):
            raise SystemExit(f"{name}:{n}: unescaped double hyphen")
        if "\u2013" in ln or "\u2014" in ln:
            raise SystemExit(f"{name}:{n}: literal dash")

for key, (v, f) in sorted(latest.items()):
    body = convert(f)
    title = next(l for l in body.splitlines() if l.startswith("= "))[2:].replace('"', '\\"')
    head = ('#import "../template.typ": *\n'
            f'#show: book-setup.with(title: "{title}", lang: "en", running: "{title[:90]}")\n\n')
    text = head + body
    name = f.stem + ".typ"
    check(text, name)
    (OUT / name).write_text(text, encoding="utf-8")
    print("wrote", name)

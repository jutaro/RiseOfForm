// Rise of Form / Werden der Form: shared Typst template.
// Used by book-en.typ, book-de.typ and the per-chapter builds.

#let accent = rgb("#b5432a")
#let ink = rgb("#1f1f1f")
#let mute = rgb("#6b6b6b")
#let rule = rgb("#d9d9d9")

// The two-hyphen and three-hyphen shorthands are disabled by the dash rule
// (no em or en dashes in any output). Any dash that slips through the source
// is caught by the post-build check in build.py; these show rules are a
// second net that flattens them to a plain hyphen with spaces.
#let dash-guard(body) = {
  show sym.dash.em: " - "
  show sym.dash.en: "-"
  body
}

#let book-setup(title: "", lang: "en", running: "", body) = {
  set document(title: title, author: "Project secret3, Row B")
  set page(
    paper: "a4",
    margin: (top: 2.4cm, bottom: 2.6cm, left: 2.6cm, right: 2.6cm),
    footer: context {
      set text(size: 8pt, fill: mute)
      let n = counter(page).get().first()
      grid(columns: (1fr, auto), running, str(n))
    },
  )
  set text(font: "Barlow", size: 10.5pt, fill: ink, lang: lang, hyphenate: true)
  set par(justify: false, leading: 0.68em, spacing: 0.95em)
  show raw: set text(font: "DejaVu Sans Mono", size: 8.6pt)
  set raw(syntaxes: "idris.sublime-syntax")
  show raw.where(lang: "idris"): set raw(theme: "idris.tmTheme")
  show raw.where(block: true): it => block(
    width: 100%, inset: (x: 9pt, y: 7pt), radius: 2pt,
    fill: luma(247), stroke: (left: 2pt + rule), it,
  )
  set table(stroke: (x, y) => if y == 0 { (bottom: 0.6pt + ink) } else { (bottom: 0.4pt + rule) }, inset: (x: 8pt, y: 5pt))
  show table: set text(size: 9.5pt)
  show table.cell.where(y: 0): set text(weight: "semibold")

  // Chapter title
  show heading.where(level: 1): it => {
    pagebreak(weak: true)
    v(1.2cm)
    block(below: 0.5cm)[
      #set text(size: 22pt, weight: "bold")
      #it.body
    ]
  }
  // Section title
  show heading.where(level: 2): it => block(above: 1.5em, below: 0.7em)[
    #set text(size: 11.5pt, weight: "semibold")
    #it.body
  ]
  show heading.where(level: 3): it => block(above: 1.2em, below: 0.5em)[
    #set text(size: 10.5pt, weight: "semibold", style: "italic")
    #it.body
  ]
  set heading(numbering: none)
  dash-guard(body)
}

// The draft line under a chapter title ("Chapter draft v0.5, Project secret3, Row B, ...").
#let draftline(body) = block(below: 1.1em)[
  #set text(size: 9.5pt, weight: "semibold", fill: accent)
  #body
]

// The italic front note that opens the book ("A note before the chapters...").
#let frontnote(body) = block(below: 1.2em)[
  #set text(style: "italic")
  #body
]

// Book title page.
#let titlepage(title, subtitle, note) = {
  v(6cm)
  text(size: 34pt, weight: "bold")[#title]
  v(0.4cm)
  text(size: 13pt, fill: accent, weight: "semibold")[#subtitle]
  v(1cm)
  text(size: 10pt, fill: mute)[#note]
  pagebreak()
}

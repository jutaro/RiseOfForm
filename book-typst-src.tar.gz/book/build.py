#!/usr/bin/env python3
"""Build all PDFs: the two assembled books and one PDF per chapter.
Usage: python3 build.py [outdir]   (default /mnt/user-data/outputs)
Runs the dash check on every produced PDF (no em or en dashes allowed).
"""
import pathlib, sys, subprocess, tempfile
import typst

HERE = pathlib.Path(__file__).parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/outputs")
OUT.mkdir(parents=True, exist_ok=True)
FONTS = [str(HERE / "fonts")]

TITLES = {"en": ("Rise of Form", "en"), "de": ("Werden der Form", "de")}

def compile_(src: pathlib.Path, pdf: pathlib.Path):
    typst.compile(str(src), output=str(pdf), root=str(HERE), font_paths=FONTS)

def check_dashes(pdf: pathlib.Path):
    txt = subprocess.run(["pdftotext", str(pdf), "-"], capture_output=True, text=True).stdout
    bad = [c for c in "\u2013\u2014" if c in txt]
    if bad:
        raise SystemExit(f"DASH CHECK FAILED: {pdf.name} contains {bad}")

def chapter_pdf(lang: str, ch: pathlib.Path):
    book, code = TITLES[lang]
    title_line = next(l for l in ch.read_text(encoding="utf-8").splitlines() if l.startswith("= "))[2:]
    draft = next((l for l in ch.read_text(encoding="utf-8").splitlines() if l.startswith("#draftline[")), "")
    ver = ""
    import re
    m = re.search(r"v\d+\.\d+", draft)
    if m: ver = "-" + m.group(0)
    wrapper = HERE / f"_wrap-{lang}-{ch.stem}.typ"
    wrapper.write_text(
        f'#import "template.typ": *\n'
        f'#show: book-setup.with(title: "{book}: {title_line}", lang: "{code}", running: "{book}: {title_line}")\n'
        f'#include "{ch.relative_to(HERE).as_posix()}"\n', encoding="utf-8")
    prefix = "rise-of-form-chapter-" if lang == "en" else "werden-der-form-kapitel-"
    suffix = "" if lang == "en" else "-de"
    pdf = OUT / f"{prefix}{ch.stem[3:]}{ver}{suffix}.pdf"
    compile_(wrapper, pdf)
    wrapper.unlink()
    check_dashes(pdf)
    print("built", pdf.name)

for lang in ("en", "de"):
    pdf = OUT / (f"rise-of-form-book-draft.pdf" if lang == "en" else "werden-der-form-buch-entwurf.pdf")
    compile_(HERE / f"book-{lang}.typ", pdf)
    check_dashes(pdf)
    print("built", pdf.name)
    for ch in sorted((HERE / "chapters" / lang).glob("*.typ")):
        chapter_pdf(lang, ch)
for src in sorted((HERE / "papers").glob("*.typ")):
    pdf = OUT / (src.stem + ".pdf")
    compile_(src, pdf)
    check_dashes(pdf)
    print("built", pdf.name)
print("all PDFs pass the dash check")
